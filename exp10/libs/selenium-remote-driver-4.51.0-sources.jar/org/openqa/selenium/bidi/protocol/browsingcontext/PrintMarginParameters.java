// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.browsingcontext;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class PrintMarginParameters {

  private Optional<Number> bottom;
  private Optional<Number> left;
  private Optional<Number> right;
  private Optional<Number> top;

  public PrintMarginParameters() {
    this.bottom = Optional.empty();
    this.left = Optional.empty();
    this.right = Optional.empty();
    this.top = Optional.empty();
  }

  PrintMarginParameters(Optional<Number> bottom, Optional<Number> left, Optional<Number> right, Optional<Number> top) {
    this.bottom = bottom != null ? bottom : Optional.empty();
    this.left = left != null ? left : Optional.empty();
    this.right = right != null ? right : Optional.empty();
    this.top = top != null ? top : Optional.empty();
  }

  public PrintMarginParameters setBottom(Number bottom) {
    this.bottom = Optional.ofNullable(bottom);
    return this;
  }

  public PrintMarginParameters setLeft(Number left) {
    this.left = Optional.ofNullable(left);
    return this;
  }

  public PrintMarginParameters setRight(Number right) {
    this.right = Optional.ofNullable(right);
    return this;
  }

  public PrintMarginParameters setTop(Number top) {
    this.top = Optional.ofNullable(top);
    return this;
  }

  public Optional<Number> getBottom() {
    return bottom;
  }

  public Optional<Number> getLeft() {
    return left;
  }

  public Optional<Number> getRight() {
    return right;
  }

  public Optional<Number> getTop() {
    return top;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    bottom.ifPresent(v -> map.put("bottom", v));
    left.ifPresent(v -> map.put("left", v));
    right.ifPresent(v -> map.put("right", v));
    top.ifPresent(v -> map.put("top", v));
    return Collections.unmodifiableMap(map);
  }

}
