// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.input;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class SetFilesParameters {

  private final String context;
  private final org.openqa.selenium.bidi.protocol.script.SharedReference element;
  private final java.util.List<String> files;

  public SetFilesParameters(String context, org.openqa.selenium.bidi.protocol.script.SharedReference element, java.util.List<String> files) {
    this.context = Objects.requireNonNull(context, "context is required");
    this.element = Objects.requireNonNull(element, "element is required");
    this.files = Objects.requireNonNull(files, "files is required");
  }

  public String getContext() {
    return context;
  }

  public org.openqa.selenium.bidi.protocol.script.SharedReference getElement() {
    return element;
  }

  public java.util.List<String> getFiles() {
    return files;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("context", context);
    map.put("element", element.toMap());
    map.put("files", files.stream().map(e -> java.util.Objects.requireNonNull(e, "files element must not be null")).collect(java.util.stream.Collectors.toList()));
    return Collections.unmodifiableMap(map);
  }

}
