// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.module;

import org.jetbrains.annotations.ApiStatus;
import org.openqa.selenium.Beta;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.bidi.Command;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.bidi.Event;
import org.openqa.selenium.bidi.Module;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
@SuppressWarnings("unchecked")
public class Storage extends Module {

  public Storage(WebDriver driver) {
    super(driver);
  }

  public org.openqa.selenium.bidi.protocol.storage.DeleteCookiesResult deleteCookies(org.openqa.selenium.bidi.protocol.storage.DeleteCookiesParameters params) {
    return send(new Command<>("storage.deleteCookies", params.toMap(), org.openqa.selenium.bidi.protocol.storage.DeleteCookiesResult.class));
  }

  public org.openqa.selenium.bidi.protocol.storage.GetCookiesResult getCookies(org.openqa.selenium.bidi.protocol.storage.GetCookiesParameters params) {
    return send(new Command<>("storage.getCookies", params.toMap(), org.openqa.selenium.bidi.protocol.storage.GetCookiesResult.class));
  }

  public org.openqa.selenium.bidi.protocol.storage.SetCookieResult setCookie(org.openqa.selenium.bidi.protocol.storage.SetCookieParameters params) {
    return send(new Command<>("storage.setCookie", params.toMap(), org.openqa.selenium.bidi.protocol.storage.SetCookieResult.class));
  }

}
