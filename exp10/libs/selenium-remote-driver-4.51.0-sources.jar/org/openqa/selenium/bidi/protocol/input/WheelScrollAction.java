// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.input;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class WheelScrollAction implements WheelSourceAction {

  private final String type;
  private final long x;
  private final long y;
  private final long deltaX;
  private final long deltaY;
  private Optional<Long> duration;
  private Optional<Origin> origin;

  public WheelScrollAction(String type, long x, long y, long deltaX, long deltaY) {
    if (!Objects.equals(type, "scroll")) {
      throw new BiDiException("type must be " + "scroll" + ", got: " + type);
    }
    this.type = Objects.requireNonNull(type, "type is required");
    if (x < -9007199254740991L || x > 9007199254740991L) {
      throw new BiDiException("x must be between -9007199254740991 and 9007199254740991, got: " + x);
    }
    this.x = x;
    if (y < -9007199254740991L || y > 9007199254740991L) {
      throw new BiDiException("y must be between -9007199254740991 and 9007199254740991, got: " + y);
    }
    this.y = y;
    if (deltaX < -9007199254740991L || deltaX > 9007199254740991L) {
      throw new BiDiException("deltaX must be between -9007199254740991 and 9007199254740991, got: " + deltaX);
    }
    this.deltaX = deltaX;
    if (deltaY < -9007199254740991L || deltaY > 9007199254740991L) {
      throw new BiDiException("deltaY must be between -9007199254740991 and 9007199254740991, got: " + deltaY);
    }
    this.deltaY = deltaY;
    this.duration = Optional.empty();
    this.origin = Optional.empty();
  }

  WheelScrollAction(String type, long x, long y, long deltaX, long deltaY, Optional<Long> duration, Optional<Origin> origin) {
    if (!Objects.equals(type, "scroll")) {
      throw new BiDiException("type must be " + "scroll" + ", got: " + type);
    }
    this.type = Objects.requireNonNull(type, "type is required");
    if (x < -9007199254740991L || x > 9007199254740991L) {
      throw new BiDiException("x must be between -9007199254740991 and 9007199254740991, got: " + x);
    }
    this.x = x;
    if (y < -9007199254740991L || y > 9007199254740991L) {
      throw new BiDiException("y must be between -9007199254740991 and 9007199254740991, got: " + y);
    }
    this.y = y;
    if (deltaX < -9007199254740991L || deltaX > 9007199254740991L) {
      throw new BiDiException("deltaX must be between -9007199254740991 and 9007199254740991, got: " + deltaX);
    }
    this.deltaX = deltaX;
    if (deltaY < -9007199254740991L || deltaY > 9007199254740991L) {
      throw new BiDiException("deltaY must be between -9007199254740991 and 9007199254740991, got: " + deltaY);
    }
    this.deltaY = deltaY;
    if (duration != null && duration.isPresent() && (duration.get() < 0L || duration.get() > 9007199254740991L)) {
      throw new BiDiException("duration must be between 0 and 9007199254740991, got: " + duration.get());
    }
    this.duration = duration != null ? duration : Optional.empty();
    this.origin = origin != null ? origin : Optional.empty();
  }

  public WheelScrollAction setDuration(Long duration) {
    if (duration != null && (duration < 0L || duration > 9007199254740991L)) {
      throw new BiDiException("duration must be between 0 and 9007199254740991, got: " + duration);
    }
    this.duration = Optional.ofNullable(duration);
    return this;
  }

  public WheelScrollAction setOrigin(Origin origin) {
    this.origin = Optional.ofNullable(origin);
    return this;
  }

  public String getType() {
    return type;
  }

  public long getX() {
    return x;
  }

  public long getY() {
    return y;
  }

  public long getDeltaX() {
    return deltaX;
  }

  public long getDeltaY() {
    return deltaY;
  }

  public Optional<Long> getDuration() {
    return duration;
  }

  public Optional<Origin> getOrigin() {
    return origin;
  }

  @Override
  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("type", type);
    map.put("x", x);
    map.put("y", y);
    map.put("deltaX", deltaX);
    map.put("deltaY", deltaY);
    duration.ifPresent(v -> map.put("duration", v));
    origin.ifPresent(v -> map.put("origin", v.toWireValue()));
    return Collections.unmodifiableMap(map);
  }

}
