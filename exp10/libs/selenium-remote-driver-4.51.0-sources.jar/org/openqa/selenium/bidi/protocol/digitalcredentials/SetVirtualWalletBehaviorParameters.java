// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.digitalcredentials;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class SetVirtualWalletBehaviorParameters {

  private final VirtualWalletAction action;
  private Optional<String> context;
  private Optional<String> protocol;
  private Optional<SetVirtualWalletBehaviorParameters.Response> response;

  public SetVirtualWalletBehaviorParameters(VirtualWalletAction action) {
    this.action = Objects.requireNonNull(action, "action is required");
    this.context = Optional.empty();
    this.protocol = Optional.empty();
    this.response = Optional.empty();
  }

  SetVirtualWalletBehaviorParameters(VirtualWalletAction action, Optional<String> context, Optional<String> protocol, Optional<SetVirtualWalletBehaviorParameters.Response> response) {
    this.action = Objects.requireNonNull(action, "action is required");
    this.context = context != null ? context : Optional.empty();
    this.protocol = protocol != null ? protocol : Optional.empty();
    this.response = response != null ? response : Optional.empty();
  }

  public SetVirtualWalletBehaviorParameters setContext(String context) {
    this.context = Optional.ofNullable(context);
    return this;
  }

  public SetVirtualWalletBehaviorParameters setProtocol(String protocol) {
    this.protocol = Optional.ofNullable(protocol);
    return this;
  }

  public SetVirtualWalletBehaviorParameters setResponse(SetVirtualWalletBehaviorParameters.Response response) {
    this.response = Optional.ofNullable(response);
    return this;
  }

  public VirtualWalletAction getAction() {
    return action;
  }

  public Optional<String> getContext() {
    return context;
  }

  public Optional<String> getProtocol() {
    return protocol;
  }

  public Optional<SetVirtualWalletBehaviorParameters.Response> getResponse() {
    return response;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("action", action.toWireValue());
    context.ifPresent(v -> map.put("context", v));
    protocol.ifPresent(v -> map.put("protocol", v));
    response.ifPresent(v -> map.put("response", v.toMap()));
    return Collections.unmodifiableMap(map);
  }


  public static class Response {

    private final Map<String, Object> extensions = new LinkedHashMap<>();
    private static final Set<String> DEFINED_FIELDS =
        Set.of();

    public Response() {
    }

    public Response addExtension(String key, Object value) {
      if (DEFINED_FIELDS.contains(key)) {
        throw new BiDiException("Cannot add an extension for a declared field: " + key);
      }
      this.extensions.put(key, value);
      return this;
    }

    public Map<String, Object> getExtensions() {
      return Collections.unmodifiableMap(extensions);
    }

    public Map<String, Object> toMap() {
      Map<String, Object> map = new LinkedHashMap<>();
      extensions.forEach(map::put);
      return Collections.unmodifiableMap(map);
    }

  }
}
