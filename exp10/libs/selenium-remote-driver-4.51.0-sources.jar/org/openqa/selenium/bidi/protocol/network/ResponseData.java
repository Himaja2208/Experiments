// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.network;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
@WarnOnUnknownFields
public class ResponseData {

  private final String url;
  private final String protocol;
  private final long status;
  private final String statusText;
  private final boolean fromCache;
  private final java.util.List<Header> headers;
  private final String mimeType;
  private final long bytesReceived;
  private final Long headersSize;
  private final Long bodySize;
  private final ResponseContent content;
  private final Optional<java.util.List<AuthChallenge>> authChallenges;

  ResponseData(String url, String protocol, long status, String statusText, boolean fromCache, java.util.List<Header> headers, String mimeType, long bytesReceived, @Nullable Long headersSize, @Nullable Long bodySize, ResponseContent content, Optional<java.util.List<AuthChallenge>> authChallenges) {
    this.url = Objects.requireNonNull(url, "url is required");
    this.protocol = Objects.requireNonNull(protocol, "protocol is required");
    if (status < 0L || status > 9007199254740991L) {
      throw new BiDiException("status must be between 0 and 9007199254740991, got: " + status);
    }
    this.status = status;
    this.statusText = Objects.requireNonNull(statusText, "statusText is required");
    this.fromCache = fromCache;
    this.headers = java.util.Collections.unmodifiableList(new java.util.ArrayList<>(Objects.requireNonNull(headers, "headers is required")));
    this.mimeType = Objects.requireNonNull(mimeType, "mimeType is required");
    if (bytesReceived < 0L || bytesReceived > 9007199254740991L) {
      throw new BiDiException("bytesReceived must be between 0 and 9007199254740991, got: " + bytesReceived);
    }
    this.bytesReceived = bytesReceived;
    if (headersSize != null && (headersSize < 0L || headersSize > 9007199254740991L)) {
      throw new BiDiException("headersSize must be between 0 and 9007199254740991, got: " + headersSize);
    }
    this.headersSize = headersSize;
    if (bodySize != null && (bodySize < 0L || bodySize > 9007199254740991L)) {
      throw new BiDiException("bodySize must be between 0 and 9007199254740991, got: " + bodySize);
    }
    this.bodySize = bodySize;
    this.content = Objects.requireNonNull(content, "content is required");
    Optional<java.util.List<AuthChallenge>> authChallengesValue = authChallenges != null ? authChallenges : Optional.empty();
    this.authChallenges = authChallengesValue.map(v -> java.util.Collections.unmodifiableList(new java.util.ArrayList<>(v)));
  }

  public String getUrl() {
    return url;
  }

  public String getProtocol() {
    return protocol;
  }

  public long getStatus() {
    return status;
  }

  public String getStatusText() {
    return statusText;
  }

  public boolean getFromCache() {
    return fromCache;
  }

  public java.util.List<Header> getHeaders() {
    return headers;
  }

  public String getMimeType() {
    return mimeType;
  }

  public long getBytesReceived() {
    return bytesReceived;
  }

  public Long getHeadersSize() {
    return headersSize;
  }

  public Long getBodySize() {
    return bodySize;
  }

  public ResponseContent getContent() {
    return content;
  }

  public Optional<java.util.List<AuthChallenge>> getAuthChallenges() {
    return authChallenges;
  }

}
