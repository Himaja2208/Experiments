// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.bluetooth;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class SimulateAdapterParameters {

  private final String context;
  private Optional<Boolean> leSupported;
  private final SimulateAdapterParameters.State state;

  public SimulateAdapterParameters(String context, SimulateAdapterParameters.State state) {
    this.context = Objects.requireNonNull(context, "context is required");
    this.state = Objects.requireNonNull(state, "state is required");
    this.leSupported = Optional.empty();
  }

  SimulateAdapterParameters(String context, Optional<Boolean> leSupported, SimulateAdapterParameters.State state) {
    this.context = Objects.requireNonNull(context, "context is required");
    this.leSupported = leSupported != null ? leSupported : Optional.empty();
    this.state = Objects.requireNonNull(state, "state is required");
  }

  public SimulateAdapterParameters setLeSupported(Boolean leSupported) {
    this.leSupported = Optional.ofNullable(leSupported);
    return this;
  }

  public String getContext() {
    return context;
  }

  public Optional<Boolean> getLeSupported() {
    return leSupported;
  }

  public SimulateAdapterParameters.State getState() {
    return state;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("context", context);
    map.put("state", state.toWireValue());
    leSupported.ifPresent(v -> map.put("leSupported", v));
    return Collections.unmodifiableMap(map);
  }


  public enum State {

    ABSENT("absent"),
    POWERED_OFF("powered-off"),
    POWERED_ON("powered-on");

    private final String value;

    State(String value) {
      this.value = value;
    }

    public static State fromJson(String s) {
      for (State e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown State value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }
}
