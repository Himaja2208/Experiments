// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.browsingcontext;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class HandleUserPromptParameters {

  private final String context;
  private Optional<Boolean> accept;
  private Optional<String> userText;

  public HandleUserPromptParameters(String context) {
    this.context = Objects.requireNonNull(context, "context is required");
    this.accept = Optional.empty();
    this.userText = Optional.empty();
  }

  HandleUserPromptParameters(String context, Optional<Boolean> accept, Optional<String> userText) {
    this.context = Objects.requireNonNull(context, "context is required");
    this.accept = accept != null ? accept : Optional.empty();
    this.userText = userText != null ? userText : Optional.empty();
  }

  public HandleUserPromptParameters setAccept(Boolean accept) {
    this.accept = Optional.ofNullable(accept);
    return this;
  }

  public HandleUserPromptParameters setUserText(String userText) {
    this.userText = Optional.ofNullable(userText);
    return this;
  }

  public String getContext() {
    return context;
  }

  public Optional<Boolean> getAccept() {
    return accept;
  }

  public Optional<String> getUserText() {
    return userText;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("context", context);
    accept.ifPresent(v -> map.put("accept", v));
    userText.ifPresent(v -> map.put("userText", v));
    return Collections.unmodifiableMap(map);
  }

}
