// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.network;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class AddDataCollectorParameters {

  private final java.util.List<DataType> dataTypes;
  private final long maxEncodedDataSize;
  private Optional<CollectorType> collectorType;
  private Optional<java.util.List<String>> contexts;
  private Optional<java.util.List<String>> userContexts;

  public AddDataCollectorParameters(java.util.List<DataType> dataTypes, long maxEncodedDataSize) {
    this.dataTypes = Objects.requireNonNull(dataTypes, "dataTypes is required");
    if (maxEncodedDataSize < 0L || maxEncodedDataSize > 9007199254740991L) {
      throw new BiDiException("maxEncodedDataSize must be between 0 and 9007199254740991, got: " + maxEncodedDataSize);
    }
    this.maxEncodedDataSize = maxEncodedDataSize;
    this.collectorType = Optional.empty();
    this.contexts = Optional.empty();
    this.userContexts = Optional.empty();
  }

  AddDataCollectorParameters(java.util.List<DataType> dataTypes, long maxEncodedDataSize, Optional<CollectorType> collectorType, Optional<java.util.List<String>> contexts, Optional<java.util.List<String>> userContexts) {
    this.dataTypes = Objects.requireNonNull(dataTypes, "dataTypes is required");
    if (maxEncodedDataSize < 0L || maxEncodedDataSize > 9007199254740991L) {
      throw new BiDiException("maxEncodedDataSize must be between 0 and 9007199254740991, got: " + maxEncodedDataSize);
    }
    this.maxEncodedDataSize = maxEncodedDataSize;
    this.collectorType = collectorType != null ? collectorType : Optional.empty();
    this.contexts = contexts != null ? contexts : Optional.empty();
    this.userContexts = userContexts != null ? userContexts : Optional.empty();
  }

  public AddDataCollectorParameters setCollectorType(CollectorType collectorType) {
    this.collectorType = Optional.ofNullable(collectorType);
    return this;
  }

  public AddDataCollectorParameters setContexts(java.util.List<String> contexts) {
    this.contexts = Optional.ofNullable(contexts);
    return this;
  }

  public AddDataCollectorParameters setUserContexts(java.util.List<String> userContexts) {
    this.userContexts = Optional.ofNullable(userContexts);
    return this;
  }

  public java.util.List<DataType> getDataTypes() {
    return dataTypes;
  }

  public long getMaxEncodedDataSize() {
    return maxEncodedDataSize;
  }

  public Optional<CollectorType> getCollectorType() {
    return collectorType;
  }

  public Optional<java.util.List<String>> getContexts() {
    return contexts;
  }

  public Optional<java.util.List<String>> getUserContexts() {
    return userContexts;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("dataTypes", dataTypes.stream().map(e -> java.util.Objects.requireNonNull(e, "dataTypes element must not be null").toWireValue()).collect(java.util.stream.Collectors.toList()));
    map.put("maxEncodedDataSize", maxEncodedDataSize);
    collectorType.ifPresent(v -> map.put("collectorType", v.toWireValue()));
    contexts.ifPresent(v -> map.put("contexts", v.stream().map(e -> java.util.Objects.requireNonNull(e, "contexts element must not be null")).collect(java.util.stream.Collectors.toList())));
    userContexts.ifPresent(v -> map.put("userContexts", v.stream().map(e -> java.util.Objects.requireNonNull(e, "userContexts element must not be null")).collect(java.util.stream.Collectors.toList())));
    return Collections.unmodifiableMap(map);
  }

}
