// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.network;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
@WarnOnUnknownFields
public class Initiator {

  private final Optional<Long> columnNumber;
  private final Optional<Long> lineNumber;
  private final Optional<String> request;
  private final Optional<org.openqa.selenium.bidi.protocol.script.StackTrace> stackTrace;
  private final Optional<Initiator.Type> type;

  Initiator(Optional<Long> columnNumber, Optional<Long> lineNumber, Optional<String> request, Optional<org.openqa.selenium.bidi.protocol.script.StackTrace> stackTrace, Optional<Initiator.Type> type) {
    if (columnNumber != null && columnNumber.isPresent() && (columnNumber.get() < 0L || columnNumber.get() > 9007199254740991L)) {
      throw new BiDiException("columnNumber must be between 0 and 9007199254740991, got: " + columnNumber.get());
    }
    this.columnNumber = columnNumber != null ? columnNumber : Optional.empty();
    if (lineNumber != null && lineNumber.isPresent() && (lineNumber.get() < 0L || lineNumber.get() > 9007199254740991L)) {
      throw new BiDiException("lineNumber must be between 0 and 9007199254740991, got: " + lineNumber.get());
    }
    this.lineNumber = lineNumber != null ? lineNumber : Optional.empty();
    this.request = request != null ? request : Optional.empty();
    this.stackTrace = stackTrace != null ? stackTrace : Optional.empty();
    this.type = type != null ? type : Optional.empty();
  }

  public Optional<Long> getColumnNumber() {
    return columnNumber;
  }

  public Optional<Long> getLineNumber() {
    return lineNumber;
  }

  public Optional<String> getRequest() {
    return request;
  }

  public Optional<org.openqa.selenium.bidi.protocol.script.StackTrace> getStackTrace() {
    return stackTrace;
  }

  public Optional<Initiator.Type> getType() {
    return type;
  }


  public enum Type {

    PARSER("parser"),
    SCRIPT("script"),
    PREFLIGHT("preflight"),
    OTHER("other");

    private final String value;

    Type(String value) {
      this.value = value;
    }

    public static Type fromJson(String s) {
      for (Type e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown Type value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }
}
