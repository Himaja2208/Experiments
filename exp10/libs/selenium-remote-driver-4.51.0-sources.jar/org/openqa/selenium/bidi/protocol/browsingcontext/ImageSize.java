// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.browsingcontext;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class ImageSize {

  private Optional<Long> maxWidth;
  private Optional<Long> maxHeight;

  public ImageSize() {
    this.maxWidth = Optional.empty();
    this.maxHeight = Optional.empty();
  }

  ImageSize(Optional<Long> maxWidth, Optional<Long> maxHeight) {
    if (maxWidth != null && maxWidth.isPresent() && (maxWidth.get() < 0L || maxWidth.get() > 9007199254740991L)) {
      throw new BiDiException("maxWidth must be between 0 and 9007199254740991, got: " + maxWidth.get());
    }
    this.maxWidth = maxWidth != null ? maxWidth : Optional.empty();
    if (maxHeight != null && maxHeight.isPresent() && (maxHeight.get() < 0L || maxHeight.get() > 9007199254740991L)) {
      throw new BiDiException("maxHeight must be between 0 and 9007199254740991, got: " + maxHeight.get());
    }
    this.maxHeight = maxHeight != null ? maxHeight : Optional.empty();
  }

  public ImageSize setMaxWidth(Long maxWidth) {
    if (maxWidth != null && (maxWidth < 0L || maxWidth > 9007199254740991L)) {
      throw new BiDiException("maxWidth must be between 0 and 9007199254740991, got: " + maxWidth);
    }
    this.maxWidth = Optional.ofNullable(maxWidth);
    return this;
  }

  public ImageSize setMaxHeight(Long maxHeight) {
    if (maxHeight != null && (maxHeight < 0L || maxHeight > 9007199254740991L)) {
      throw new BiDiException("maxHeight must be between 0 and 9007199254740991, got: " + maxHeight);
    }
    this.maxHeight = Optional.ofNullable(maxHeight);
    return this;
  }

  public Optional<Long> getMaxWidth() {
    return maxWidth;
  }

  public Optional<Long> getMaxHeight() {
    return maxHeight;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    maxWidth.ifPresent(v -> map.put("maxWidth", v));
    maxHeight.ifPresent(v -> map.put("maxHeight", v));
    return Collections.unmodifiableMap(map);
  }

}
