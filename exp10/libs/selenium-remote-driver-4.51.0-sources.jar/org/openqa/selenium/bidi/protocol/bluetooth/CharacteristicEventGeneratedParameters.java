// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.bluetooth;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
@WarnOnUnknownFields
public class CharacteristicEventGeneratedParameters {

  private final String context;
  private final String address;
  private final String serviceUuid;
  private final String characteristicUuid;
  private final CharacteristicEventGeneratedParameters.Type type;
  private final Optional<java.util.List<Long>> data;

  CharacteristicEventGeneratedParameters(String context, String address, String serviceUuid, String characteristicUuid, CharacteristicEventGeneratedParameters.Type type, Optional<java.util.List<Long>> data) {
    this.context = Objects.requireNonNull(context, "context is required");
    this.address = Objects.requireNonNull(address, "address is required");
    this.serviceUuid = Objects.requireNonNull(serviceUuid, "serviceUuid is required");
    this.characteristicUuid = Objects.requireNonNull(characteristicUuid, "characteristicUuid is required");
    this.type = Objects.requireNonNull(type, "type is required");
    Optional<java.util.List<Long>> dataValue = data != null ? data : Optional.empty();
    this.data = dataValue.map(v -> java.util.Collections.unmodifiableList(new java.util.ArrayList<>(v)));
  }

  public String getContext() {
    return context;
  }

  public String getAddress() {
    return address;
  }

  public String getServiceUuid() {
    return serviceUuid;
  }

  public String getCharacteristicUuid() {
    return characteristicUuid;
  }

  public CharacteristicEventGeneratedParameters.Type getType() {
    return type;
  }

  public Optional<java.util.List<Long>> getData() {
    return data;
  }


  public enum Type {

    READ("read"),
    WRITE_WITH_RESPONSE("write-with-response"),
    WRITE_WITHOUT_RESPONSE("write-without-response"),
    SUBSCRIBE_TO_NOTIFICATIONS("subscribe-to-notifications"),
    UNSUBSCRIBE_FROM_NOTIFICATIONS("unsubscribe-from-notifications");

    private final String value;

    Type(String value) {
      this.value = value;
    }

    public static Type fromJson(String s) {
      for (Type e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown Type value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }
}
