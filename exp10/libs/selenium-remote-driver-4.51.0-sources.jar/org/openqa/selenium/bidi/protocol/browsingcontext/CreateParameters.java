// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.browsingcontext;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class CreateParameters {

  private final CreateType type;
  private Optional<String> referenceContext;
  private Optional<Boolean> background;
  private Optional<String> userContext;

  public CreateParameters(CreateType type) {
    this.type = Objects.requireNonNull(type, "type is required");
    this.referenceContext = Optional.empty();
    this.background = Optional.empty();
    this.userContext = Optional.empty();
  }

  CreateParameters(CreateType type, Optional<String> referenceContext, Optional<Boolean> background, Optional<String> userContext) {
    this.type = Objects.requireNonNull(type, "type is required");
    this.referenceContext = referenceContext != null ? referenceContext : Optional.empty();
    this.background = background != null ? background : Optional.empty();
    this.userContext = userContext != null ? userContext : Optional.empty();
  }

  public CreateParameters setReferenceContext(String referenceContext) {
    this.referenceContext = Optional.ofNullable(referenceContext);
    return this;
  }

  public CreateParameters setBackground(Boolean background) {
    this.background = Optional.ofNullable(background);
    return this;
  }

  public CreateParameters setUserContext(String userContext) {
    this.userContext = Optional.ofNullable(userContext);
    return this;
  }

  public CreateType getType() {
    return type;
  }

  public Optional<String> getReferenceContext() {
    return referenceContext;
  }

  public Optional<Boolean> getBackground() {
    return background;
  }

  public Optional<String> getUserContext() {
    return userContext;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("type", type.toWireValue());
    referenceContext.ifPresent(v -> map.put("referenceContext", v));
    background.ifPresent(v -> map.put("background", v));
    userContext.ifPresent(v -> map.put("userContext", v));
    return Collections.unmodifiableMap(map);
  }

}
