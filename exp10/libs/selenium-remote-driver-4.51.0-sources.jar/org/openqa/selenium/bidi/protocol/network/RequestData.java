// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.network;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
@WarnOnUnknownFields
public class RequestData {

  private final String request;
  private final String url;
  private final String method;
  private final java.util.List<Header> headers;
  private final java.util.List<Cookie> cookies;
  private final long headersSize;
  private final Long bodySize;
  private final String destination;
  private final String initiatorType;
  private final FetchTimingInfo timings;

  public RequestData(String request, String url, String method, java.util.List<Header> headers, java.util.List<Cookie> cookies, long headersSize, @Nullable Long bodySize, String destination, @Nullable String initiatorType, FetchTimingInfo timings) {
    this.request = Objects.requireNonNull(request, "request is required");
    this.url = Objects.requireNonNull(url, "url is required");
    this.method = Objects.requireNonNull(method, "method is required");
    this.headers = java.util.Collections.unmodifiableList(new java.util.ArrayList<>(Objects.requireNonNull(headers, "headers is required")));
    this.cookies = java.util.Collections.unmodifiableList(new java.util.ArrayList<>(Objects.requireNonNull(cookies, "cookies is required")));
    if (headersSize < 0L || headersSize > 9007199254740991L) {
      throw new BiDiException("headersSize must be between 0 and 9007199254740991, got: " + headersSize);
    }
    this.headersSize = headersSize;
    if (bodySize != null && (bodySize < 0L || bodySize > 9007199254740991L)) {
      throw new BiDiException("bodySize must be between 0 and 9007199254740991, got: " + bodySize);
    }
    this.bodySize = bodySize;
    this.destination = Objects.requireNonNull(destination, "destination is required");
    this.initiatorType = initiatorType;
    this.timings = Objects.requireNonNull(timings, "timings is required");
  }

  public String getRequest() {
    return request;
  }

  public String getUrl() {
    return url;
  }

  public String getMethod() {
    return method;
  }

  public java.util.List<Header> getHeaders() {
    return headers;
  }

  public java.util.List<Cookie> getCookies() {
    return cookies;
  }

  public long getHeadersSize() {
    return headersSize;
  }

  public Long getBodySize() {
    return bodySize;
  }

  public String getDestination() {
    return destination;
  }

  public String getInitiatorType() {
    return initiatorType;
  }

  public FetchTimingInfo getTimings() {
    return timings;
  }

}
