// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.network;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class Cookie {

  private final String name;
  private final BytesValue value;
  private final String domain;
  private final String path;
  private final long size;
  private final boolean httpOnly;
  private final boolean secure;
  private final SameSite sameSite;
  private final Optional<Long> expiry;
  private final Map<String, Object> extensions;
  private static final Set<String> DEFINED_FIELDS =
      Set.of("name", "value", "domain", "path", "size", "httpOnly", "secure", "sameSite", "expiry");

  Cookie(String name, BytesValue value, String domain, String path, long size, boolean httpOnly, boolean secure, SameSite sameSite, Optional<Long> expiry, Map<String, Object> extensions) {
    this.name = Objects.requireNonNull(name, "name is required");
    this.value = Objects.requireNonNull(value, "value is required");
    this.domain = Objects.requireNonNull(domain, "domain is required");
    this.path = Objects.requireNonNull(path, "path is required");
    if (size < 0L || size > 9007199254740991L) {
      throw new BiDiException("size must be between 0 and 9007199254740991, got: " + size);
    }
    this.size = size;
    this.httpOnly = httpOnly;
    this.secure = secure;
    this.sameSite = Objects.requireNonNull(sameSite, "sameSite is required");
    if (expiry != null && expiry.isPresent() && (expiry.get() < 0L || expiry.get() > 9007199254740991L)) {
      throw new BiDiException("expiry must be between 0 and 9007199254740991, got: " + expiry.get());
    }
    this.expiry = expiry != null ? expiry : Optional.empty();
    this.extensions = new LinkedHashMap<>(extensions);
  }

  public String getName() {
    return name;
  }

  public BytesValue getValue() {
    return value;
  }

  public String getDomain() {
    return domain;
  }

  public String getPath() {
    return path;
  }

  public long getSize() {
    return size;
  }

  public boolean getHttpOnly() {
    return httpOnly;
  }

  public boolean getSecure() {
    return secure;
  }

  public SameSite getSameSite() {
    return sameSite;
  }

  public Optional<Long> getExpiry() {
    return expiry;
  }

  public Map<String, Object> getExtensions() {
    return Collections.unmodifiableMap(extensions);
  }


  private static Cookie fromJson(Map<String, Object> map) {
    Json json = ConverterFunctions.JSON;
    String name = json.toType(json.toJson(map.get("name")), new TypeToken<String>() {}.getType());
    BytesValue value = json.toType(json.toJson(map.get("value")), new TypeToken<BytesValue>() {}.getType());
    String domain = json.toType(json.toJson(map.get("domain")), new TypeToken<String>() {}.getType());
    String path = json.toType(json.toJson(map.get("path")), new TypeToken<String>() {}.getType());
    Long size = json.toType(json.toJson(map.get("size")), new TypeToken<Long>() {}.getType());
    Boolean httpOnly = json.toType(json.toJson(map.get("httpOnly")), new TypeToken<Boolean>() {}.getType());
    Boolean secure = json.toType(json.toJson(map.get("secure")), new TypeToken<Boolean>() {}.getType());
    SameSite sameSite = json.toType(json.toJson(map.get("sameSite")), new TypeToken<SameSite>() {}.getType());
    Optional<Long> expiry = json.toType(json.toJson(map.get("expiry")), new TypeToken<Optional<Long>>() {}.getType());
    Map<String, Object> extensions = new LinkedHashMap<>();
    for (Map.Entry<String, Object> entry : map.entrySet()) {
      if (!DEFINED_FIELDS.contains(entry.getKey())) {
        extensions.put(entry.getKey(), entry.getValue());
      }
    }
    return new Cookie(name, value, domain, path, size, httpOnly, secure, sameSite, expiry, extensions);
  }
}
