// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.network;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class SetCookieHeader {

  private final String name;
  private final BytesValue value;
  private Optional<String> domain;
  private Optional<Boolean> httpOnly;
  private Optional<String> expiry;
  private Optional<Long> maxAge;
  private Optional<String> path;
  private Optional<SameSite> sameSite;
  private Optional<Boolean> secure;

  public SetCookieHeader(String name, BytesValue value) {
    this.name = Objects.requireNonNull(name, "name is required");
    this.value = Objects.requireNonNull(value, "value is required");
    this.domain = Optional.empty();
    this.httpOnly = Optional.empty();
    this.expiry = Optional.empty();
    this.maxAge = Optional.empty();
    this.path = Optional.empty();
    this.sameSite = Optional.empty();
    this.secure = Optional.empty();
  }

  SetCookieHeader(String name, BytesValue value, Optional<String> domain, Optional<Boolean> httpOnly, Optional<String> expiry, Optional<Long> maxAge, Optional<String> path, Optional<SameSite> sameSite, Optional<Boolean> secure) {
    this.name = Objects.requireNonNull(name, "name is required");
    this.value = Objects.requireNonNull(value, "value is required");
    this.domain = domain != null ? domain : Optional.empty();
    this.httpOnly = httpOnly != null ? httpOnly : Optional.empty();
    this.expiry = expiry != null ? expiry : Optional.empty();
    if (maxAge != null && maxAge.isPresent() && (maxAge.get() < -9007199254740991L || maxAge.get() > 9007199254740991L)) {
      throw new BiDiException("maxAge must be between -9007199254740991 and 9007199254740991, got: " + maxAge.get());
    }
    this.maxAge = maxAge != null ? maxAge : Optional.empty();
    this.path = path != null ? path : Optional.empty();
    this.sameSite = sameSite != null ? sameSite : Optional.empty();
    this.secure = secure != null ? secure : Optional.empty();
  }

  public SetCookieHeader setDomain(String domain) {
    this.domain = Optional.ofNullable(domain);
    return this;
  }

  public SetCookieHeader setHttpOnly(Boolean httpOnly) {
    this.httpOnly = Optional.ofNullable(httpOnly);
    return this;
  }

  public SetCookieHeader setExpiry(String expiry) {
    this.expiry = Optional.ofNullable(expiry);
    return this;
  }

  public SetCookieHeader setMaxAge(Long maxAge) {
    if (maxAge != null && (maxAge < -9007199254740991L || maxAge > 9007199254740991L)) {
      throw new BiDiException("maxAge must be between -9007199254740991 and 9007199254740991, got: " + maxAge);
    }
    this.maxAge = Optional.ofNullable(maxAge);
    return this;
  }

  public SetCookieHeader setPath(String path) {
    this.path = Optional.ofNullable(path);
    return this;
  }

  public SetCookieHeader setSameSite(SameSite sameSite) {
    this.sameSite = Optional.ofNullable(sameSite);
    return this;
  }

  public SetCookieHeader setSecure(Boolean secure) {
    this.secure = Optional.ofNullable(secure);
    return this;
  }

  public String getName() {
    return name;
  }

  public BytesValue getValue() {
    return value;
  }

  public Optional<String> getDomain() {
    return domain;
  }

  public Optional<Boolean> getHttpOnly() {
    return httpOnly;
  }

  public Optional<String> getExpiry() {
    return expiry;
  }

  public Optional<Long> getMaxAge() {
    return maxAge;
  }

  public Optional<String> getPath() {
    return path;
  }

  public Optional<SameSite> getSameSite() {
    return sameSite;
  }

  public Optional<Boolean> getSecure() {
    return secure;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("name", name);
    map.put("value", value.toMap());
    domain.ifPresent(v -> map.put("domain", v));
    httpOnly.ifPresent(v -> map.put("httpOnly", v));
    expiry.ifPresent(v -> map.put("expiry", v));
    maxAge.ifPresent(v -> map.put("maxAge", v));
    path.ifPresent(v -> map.put("path", v));
    sameSite.ifPresent(v -> map.put("sameSite", v.toWireValue()));
    secure.ifPresent(v -> map.put("secure", v));
    return Collections.unmodifiableMap(map);
  }

}
