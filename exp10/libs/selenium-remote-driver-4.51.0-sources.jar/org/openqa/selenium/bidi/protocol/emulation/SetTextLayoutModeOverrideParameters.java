// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.emulation;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class SetTextLayoutModeOverrideParameters {

  private final TextLayoutMode textLayoutMode;
  private Optional<java.util.List<String>> contexts;
  private Optional<java.util.List<String>> userContexts;

  public SetTextLayoutModeOverrideParameters(@Nullable TextLayoutMode textLayoutMode) {
    this.textLayoutMode = textLayoutMode;
    this.contexts = Optional.empty();
    this.userContexts = Optional.empty();
  }

  SetTextLayoutModeOverrideParameters(@Nullable TextLayoutMode textLayoutMode, Optional<java.util.List<String>> contexts, Optional<java.util.List<String>> userContexts) {
    this.textLayoutMode = textLayoutMode;
    this.contexts = contexts != null ? contexts : Optional.empty();
    this.userContexts = userContexts != null ? userContexts : Optional.empty();
  }

  public SetTextLayoutModeOverrideParameters setContexts(java.util.List<String> contexts) {
    this.contexts = Optional.ofNullable(contexts);
    return this;
  }

  public SetTextLayoutModeOverrideParameters setUserContexts(java.util.List<String> userContexts) {
    this.userContexts = Optional.ofNullable(userContexts);
    return this;
  }

  public TextLayoutMode getTextLayoutMode() {
    return textLayoutMode;
  }

  public Optional<java.util.List<String>> getContexts() {
    return contexts;
  }

  public Optional<java.util.List<String>> getUserContexts() {
    return userContexts;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("textLayoutMode", textLayoutMode == null ? null : textLayoutMode.toWireValue());
    contexts.ifPresent(v -> map.put("contexts", v.stream().map(e -> java.util.Objects.requireNonNull(e, "contexts element must not be null")).collect(java.util.stream.Collectors.toList())));
    userContexts.ifPresent(v -> map.put("userContexts", v.stream().map(e -> java.util.Objects.requireNonNull(e, "userContexts element must not be null")).collect(java.util.stream.Collectors.toList())));
    return Collections.unmodifiableMap(map);
  }

}
