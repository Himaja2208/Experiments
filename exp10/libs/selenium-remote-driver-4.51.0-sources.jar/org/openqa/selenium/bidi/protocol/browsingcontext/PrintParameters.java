// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.browsingcontext;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class PrintParameters {

  private final String context;
  private Optional<Boolean> background;
  private Optional<PrintMarginParameters> margin;
  private Optional<PrintParameters.Orientation> orientation;
  private Optional<PrintPageParameters> page;
  private Optional<java.util.List<Object>> pageRanges;
  private Optional<Number> scale;
  private Optional<Boolean> shrinkToFit;

  public PrintParameters(String context) {
    this.context = Objects.requireNonNull(context, "context is required");
    this.background = Optional.empty();
    this.margin = Optional.empty();
    this.orientation = Optional.empty();
    this.page = Optional.empty();
    this.pageRanges = Optional.empty();
    this.scale = Optional.empty();
    this.shrinkToFit = Optional.empty();
  }

  PrintParameters(String context, Optional<Boolean> background, Optional<PrintMarginParameters> margin, Optional<PrintParameters.Orientation> orientation, Optional<PrintPageParameters> page, Optional<java.util.List<Object>> pageRanges, Optional<Number> scale, Optional<Boolean> shrinkToFit) {
    this.context = Objects.requireNonNull(context, "context is required");
    this.background = background != null ? background : Optional.empty();
    this.margin = margin != null ? margin : Optional.empty();
    this.orientation = orientation != null ? orientation : Optional.empty();
    this.page = page != null ? page : Optional.empty();
    this.pageRanges = pageRanges != null ? pageRanges : Optional.empty();
    this.scale = scale != null ? scale : Optional.empty();
    this.shrinkToFit = shrinkToFit != null ? shrinkToFit : Optional.empty();
  }

  public PrintParameters setBackground(Boolean background) {
    this.background = Optional.ofNullable(background);
    return this;
  }

  public PrintParameters setMargin(PrintMarginParameters margin) {
    this.margin = Optional.ofNullable(margin);
    return this;
  }

  public PrintParameters setOrientation(PrintParameters.Orientation orientation) {
    this.orientation = Optional.ofNullable(orientation);
    return this;
  }

  public PrintParameters setPage(PrintPageParameters page) {
    this.page = Optional.ofNullable(page);
    return this;
  }

  public PrintParameters setPageRanges(java.util.List<Object> pageRanges) {
    this.pageRanges = Optional.ofNullable(pageRanges);
    return this;
  }

  public PrintParameters setScale(Number scale) {
    this.scale = Optional.ofNullable(scale);
    return this;
  }

  public PrintParameters setShrinkToFit(Boolean shrinkToFit) {
    this.shrinkToFit = Optional.ofNullable(shrinkToFit);
    return this;
  }

  public String getContext() {
    return context;
  }

  public Optional<Boolean> getBackground() {
    return background;
  }

  public Optional<PrintMarginParameters> getMargin() {
    return margin;
  }

  public Optional<PrintParameters.Orientation> getOrientation() {
    return orientation;
  }

  public Optional<PrintPageParameters> getPage() {
    return page;
  }

  public Optional<java.util.List<Object>> getPageRanges() {
    return pageRanges;
  }

  public Optional<Number> getScale() {
    return scale;
  }

  public Optional<Boolean> getShrinkToFit() {
    return shrinkToFit;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("context", context);
    background.ifPresent(v -> map.put("background", v));
    margin.ifPresent(v -> map.put("margin", v.toMap()));
    orientation.ifPresent(v -> map.put("orientation", v.toWireValue()));
    page.ifPresent(v -> map.put("page", v.toMap()));
    pageRanges.ifPresent(v -> map.put("pageRanges", v.stream().map(e -> java.util.Objects.requireNonNull(e, "pageRanges element must not be null")).collect(java.util.stream.Collectors.toList())));
    scale.ifPresent(v -> map.put("scale", v));
    shrinkToFit.ifPresent(v -> map.put("shrinkToFit", v));
    return Collections.unmodifiableMap(map);
  }


  public enum Orientation {

    PORTRAIT("portrait"),
    LANDSCAPE("landscape");

    private final String value;

    Orientation(String value) {
      this.value = value;
    }

    public static Orientation fromJson(String s) {
      for (Orientation e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown Orientation value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }
}
