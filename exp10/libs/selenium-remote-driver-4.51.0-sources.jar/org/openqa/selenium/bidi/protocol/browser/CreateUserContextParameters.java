// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.browser;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class CreateUserContextParameters {

  private Optional<Boolean> acceptInsecureCerts;
  private Optional<org.openqa.selenium.bidi.protocol.session.ProxyConfiguration> proxy;
  private Optional<org.openqa.selenium.bidi.protocol.session.UserPromptHandler> unhandledPromptBehavior;

  public CreateUserContextParameters() {
    this.acceptInsecureCerts = Optional.empty();
    this.proxy = Optional.empty();
    this.unhandledPromptBehavior = Optional.empty();
  }

  CreateUserContextParameters(Optional<Boolean> acceptInsecureCerts, Optional<org.openqa.selenium.bidi.protocol.session.ProxyConfiguration> proxy, Optional<org.openqa.selenium.bidi.protocol.session.UserPromptHandler> unhandledPromptBehavior) {
    this.acceptInsecureCerts = acceptInsecureCerts != null ? acceptInsecureCerts : Optional.empty();
    this.proxy = proxy != null ? proxy : Optional.empty();
    this.unhandledPromptBehavior = unhandledPromptBehavior != null ? unhandledPromptBehavior : Optional.empty();
  }

  public CreateUserContextParameters setAcceptInsecureCerts(Boolean acceptInsecureCerts) {
    this.acceptInsecureCerts = Optional.ofNullable(acceptInsecureCerts);
    return this;
  }

  public CreateUserContextParameters setProxy(org.openqa.selenium.bidi.protocol.session.ProxyConfiguration proxy) {
    this.proxy = Optional.ofNullable(proxy);
    return this;
  }

  public CreateUserContextParameters setUnhandledPromptBehavior(org.openqa.selenium.bidi.protocol.session.UserPromptHandler unhandledPromptBehavior) {
    this.unhandledPromptBehavior = Optional.ofNullable(unhandledPromptBehavior);
    return this;
  }

  public Optional<Boolean> getAcceptInsecureCerts() {
    return acceptInsecureCerts;
  }

  public Optional<org.openqa.selenium.bidi.protocol.session.ProxyConfiguration> getProxy() {
    return proxy;
  }

  public Optional<org.openqa.selenium.bidi.protocol.session.UserPromptHandler> getUnhandledPromptBehavior() {
    return unhandledPromptBehavior;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    acceptInsecureCerts.ifPresent(v -> map.put("acceptInsecureCerts", v));
    proxy.ifPresent(v -> map.put("proxy", v.toMap()));
    unhandledPromptBehavior.ifPresent(v -> map.put("unhandledPromptBehavior", v.toMap()));
    return Collections.unmodifiableMap(map);
  }

}
