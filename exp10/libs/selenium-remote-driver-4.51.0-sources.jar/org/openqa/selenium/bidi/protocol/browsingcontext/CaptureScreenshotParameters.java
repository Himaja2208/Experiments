// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.browsingcontext;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class CaptureScreenshotParameters {

  private final String context;
  private Optional<CaptureScreenshotParameters.Origin> origin;
  private Optional<ImageFormat> format;
  private Optional<ClipRectangle> clip;
  private Optional<ImageSize> imageSize;

  public CaptureScreenshotParameters(String context) {
    this.context = Objects.requireNonNull(context, "context is required");
    this.origin = Optional.empty();
    this.format = Optional.empty();
    this.clip = Optional.empty();
    this.imageSize = Optional.empty();
  }

  CaptureScreenshotParameters(String context, Optional<CaptureScreenshotParameters.Origin> origin, Optional<ImageFormat> format, Optional<ClipRectangle> clip, Optional<ImageSize> imageSize) {
    this.context = Objects.requireNonNull(context, "context is required");
    this.origin = origin != null ? origin : Optional.empty();
    this.format = format != null ? format : Optional.empty();
    this.clip = clip != null ? clip : Optional.empty();
    this.imageSize = imageSize != null ? imageSize : Optional.empty();
  }

  public CaptureScreenshotParameters setOrigin(CaptureScreenshotParameters.Origin origin) {
    this.origin = Optional.ofNullable(origin);
    return this;
  }

  public CaptureScreenshotParameters setFormat(ImageFormat format) {
    this.format = Optional.ofNullable(format);
    return this;
  }

  public CaptureScreenshotParameters setClip(ClipRectangle clip) {
    this.clip = Optional.ofNullable(clip);
    return this;
  }

  public CaptureScreenshotParameters setImageSize(ImageSize imageSize) {
    this.imageSize = Optional.ofNullable(imageSize);
    return this;
  }

  public String getContext() {
    return context;
  }

  public Optional<CaptureScreenshotParameters.Origin> getOrigin() {
    return origin;
  }

  public Optional<ImageFormat> getFormat() {
    return format;
  }

  public Optional<ClipRectangle> getClip() {
    return clip;
  }

  public Optional<ImageSize> getImageSize() {
    return imageSize;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("context", context);
    origin.ifPresent(v -> map.put("origin", v.toWireValue()));
    format.ifPresent(v -> map.put("format", v.toMap()));
    clip.ifPresent(v -> map.put("clip", v.toMap()));
    imageSize.ifPresent(v -> map.put("imageSize", v.toMap()));
    return Collections.unmodifiableMap(map);
  }


  public enum Origin {

    VIEWPORT("viewport"),
    DOCUMENT("document");

    private final String value;

    Origin(String value) {
      this.value = value;
    }

    public static Origin fromJson(String s) {
      for (Origin e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown Origin value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }
}
