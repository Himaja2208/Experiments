// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.module;

import org.jetbrains.annotations.ApiStatus;
import org.openqa.selenium.Beta;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.bidi.Command;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.bidi.Event;
import org.openqa.selenium.bidi.Module;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
@SuppressWarnings("unchecked")
public class BrowsingContext extends Module {

  public static final Event<org.openqa.selenium.bidi.protocol.browsingcontext.ContextCreatedParameters> CONTEXT_CREATED =
      new Event<>("browsingContext.contextCreated", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.browsingcontext.ContextCreatedParameters.class));

  public static final Event<org.openqa.selenium.bidi.protocol.browsingcontext.Info> CONTEXT_DESTROYED =
      new Event<>("browsingContext.contextDestroyed", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.browsingcontext.Info.class));

  public static final Event<org.openqa.selenium.bidi.protocol.browsingcontext.NavigationInfo> DOM_CONTENT_LOADED =
      new Event<>("browsingContext.domContentLoaded", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.browsingcontext.NavigationInfo.class));

  public static final Event<org.openqa.selenium.bidi.protocol.browsingcontext.DownloadEndParams> DOWNLOAD_END =
      new Event<>("browsingContext.downloadEnd", org.openqa.selenium.bidi.protocol.browsingcontext.DownloadEndParams::fromMap);

  public static final Event<org.openqa.selenium.bidi.protocol.browsingcontext.DownloadWillBeginParams> DOWNLOAD_WILL_BEGIN =
      new Event<>("browsingContext.downloadWillBegin", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.browsingcontext.DownloadWillBeginParams.class));

  public static final Event<org.openqa.selenium.bidi.protocol.browsingcontext.NavigationInfo> FRAGMENT_NAVIGATED =
      new Event<>("browsingContext.fragmentNavigated", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.browsingcontext.NavigationInfo.class));

  public static final Event<org.openqa.selenium.bidi.protocol.browsingcontext.HistoryUpdatedParameters> HISTORY_UPDATED =
      new Event<>("browsingContext.historyUpdated", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.browsingcontext.HistoryUpdatedParameters.class));

  public static final Event<org.openqa.selenium.bidi.protocol.browsingcontext.NavigationInfo> LOAD =
      new Event<>("browsingContext.load", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.browsingcontext.NavigationInfo.class));

  public static final Event<org.openqa.selenium.bidi.protocol.browsingcontext.NavigationInfo> NAVIGATION_ABORTED =
      new Event<>("browsingContext.navigationAborted", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.browsingcontext.NavigationInfo.class));

  public static final Event<org.openqa.selenium.bidi.protocol.browsingcontext.NavigationInfo> NAVIGATION_COMMITTED =
      new Event<>("browsingContext.navigationCommitted", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.browsingcontext.NavigationInfo.class));

  public static final Event<org.openqa.selenium.bidi.protocol.browsingcontext.NavigationInfo> NAVIGATION_FAILED =
      new Event<>("browsingContext.navigationFailed", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.browsingcontext.NavigationInfo.class));

  public static final Event<org.openqa.selenium.bidi.protocol.browsingcontext.NavigationInfo> NAVIGATION_STARTED =
      new Event<>("browsingContext.navigationStarted", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.browsingcontext.NavigationInfo.class));

  public static final Event<org.openqa.selenium.bidi.protocol.browsingcontext.UserPromptClosedParameters> USER_PROMPT_CLOSED =
      new Event<>("browsingContext.userPromptClosed", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.browsingcontext.UserPromptClosedParameters.class));

  public static final Event<org.openqa.selenium.bidi.protocol.browsingcontext.UserPromptOpenedParameters> USER_PROMPT_OPENED =
      new Event<>("browsingContext.userPromptOpened", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.browsingcontext.UserPromptOpenedParameters.class));

  public BrowsingContext(WebDriver driver) {
    super(driver);
  }

  public void activate(org.openqa.selenium.bidi.protocol.browsingcontext.ActivateParameters params) {
    send(new Command<>("browsingContext.activate", params.toMap()));
  }

  public org.openqa.selenium.bidi.protocol.browsingcontext.CaptureScreenshotResult captureScreenshot(org.openqa.selenium.bidi.protocol.browsingcontext.CaptureScreenshotParameters params) {
    return send(new Command<>("browsingContext.captureScreenshot", params.toMap(), org.openqa.selenium.bidi.protocol.browsingcontext.CaptureScreenshotResult.class));
  }

  public void close(org.openqa.selenium.bidi.protocol.browsingcontext.CloseParameters params) {
    send(new Command<>("browsingContext.close", params.toMap()));
  }

  public org.openqa.selenium.bidi.protocol.browsingcontext.CreateResult create(org.openqa.selenium.bidi.protocol.browsingcontext.CreateParameters params) {
    return send(new Command<>("browsingContext.create", params.toMap(), org.openqa.selenium.bidi.protocol.browsingcontext.CreateResult.class));
  }

  public org.openqa.selenium.bidi.protocol.browsingcontext.GetTreeResult getTree(org.openqa.selenium.bidi.protocol.browsingcontext.GetTreeParameters params) {
    return send(new Command<>("browsingContext.getTree", params.toMap(), org.openqa.selenium.bidi.protocol.browsingcontext.GetTreeResult.class));
  }

  public void handleUserPrompt(org.openqa.selenium.bidi.protocol.browsingcontext.HandleUserPromptParameters params) {
    send(new Command<>("browsingContext.handleUserPrompt", params.toMap()));
  }

  public org.openqa.selenium.bidi.protocol.browsingcontext.LocateNodesResult locateNodes(org.openqa.selenium.bidi.protocol.browsingcontext.LocateNodesParameters params) {
    return send(new Command<>("browsingContext.locateNodes", params.toMap(), org.openqa.selenium.bidi.protocol.browsingcontext.LocateNodesResult.class));
  }

  public org.openqa.selenium.bidi.protocol.browsingcontext.NavigateResult navigate(org.openqa.selenium.bidi.protocol.browsingcontext.NavigateParameters params) {
    return send(new Command<>("browsingContext.navigate", params.toMap(), org.openqa.selenium.bidi.protocol.browsingcontext.NavigateResult.class));
  }

  public org.openqa.selenium.bidi.protocol.browsingcontext.PrintResult print(org.openqa.selenium.bidi.protocol.browsingcontext.PrintParameters params) {
    return send(new Command<>("browsingContext.print", params.toMap(), org.openqa.selenium.bidi.protocol.browsingcontext.PrintResult.class));
  }

  public org.openqa.selenium.bidi.protocol.browsingcontext.NavigateResult reload(org.openqa.selenium.bidi.protocol.browsingcontext.ReloadParameters params) {
    return send(new Command<>("browsingContext.reload", params.toMap(), org.openqa.selenium.bidi.protocol.browsingcontext.NavigateResult.class));
  }

  public void setBypassCSP(org.openqa.selenium.bidi.protocol.browsingcontext.SetBypassCSPParameters params) {
    send(new Command<>("browsingContext.setBypassCSP", params.toMap()));
  }

  public void setViewport(org.openqa.selenium.bidi.protocol.browsingcontext.SetViewportParameters params) {
    send(new Command<>("browsingContext.setViewport", params.toMap()));
  }

  public org.openqa.selenium.bidi.protocol.browsingcontext.StartScreencastResult startScreencast(org.openqa.selenium.bidi.protocol.browsingcontext.StartScreencastParameters params) {
    return send(new Command<>("browsingContext.startScreencast", params.toMap(), org.openqa.selenium.bidi.protocol.browsingcontext.StartScreencastResult.class));
  }

  public org.openqa.selenium.bidi.protocol.browsingcontext.StopScreencastResult stopScreencast(org.openqa.selenium.bidi.protocol.browsingcontext.StopScreencastParameters params) {
    return send(new Command<>("browsingContext.stopScreencast", params.toMap(), org.openqa.selenium.bidi.protocol.browsingcontext.StopScreencastResult.class));
  }

  public void traverseHistory(org.openqa.selenium.bidi.protocol.browsingcontext.TraverseHistoryParameters params) {
    send(new Command<>("browsingContext.traverseHistory", params.toMap()));
  }

}
