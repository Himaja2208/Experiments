// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.browsingcontext;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
@WarnOnUnknownFields
public class UserPromptOpenedParameters {

  private final String context;
  private final org.openqa.selenium.bidi.protocol.session.UserPromptHandlerType handler;
  private final String message;
  private final UserPromptType type;
  private final Optional<String> userContext;
  private final Optional<String> defaultValue;

  UserPromptOpenedParameters(String context, org.openqa.selenium.bidi.protocol.session.UserPromptHandlerType handler, String message, UserPromptType type, Optional<String> userContext, Optional<String> defaultValue) {
    this.context = Objects.requireNonNull(context, "context is required");
    this.handler = Objects.requireNonNull(handler, "handler is required");
    this.message = Objects.requireNonNull(message, "message is required");
    this.type = Objects.requireNonNull(type, "type is required");
    this.userContext = userContext != null ? userContext : Optional.empty();
    this.defaultValue = defaultValue != null ? defaultValue : Optional.empty();
  }

  public String getContext() {
    return context;
  }

  public org.openqa.selenium.bidi.protocol.session.UserPromptHandlerType getHandler() {
    return handler;
  }

  public String getMessage() {
    return message;
  }

  public UserPromptType getType() {
    return type;
  }

  public Optional<String> getUserContext() {
    return userContext;
  }

  public Optional<String> getDefaultValue() {
    return defaultValue;
  }

}
