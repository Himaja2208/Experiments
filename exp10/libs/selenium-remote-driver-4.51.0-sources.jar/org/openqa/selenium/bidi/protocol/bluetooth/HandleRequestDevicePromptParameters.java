// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.bluetooth;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public interface HandleRequestDevicePromptParameters {

  Map<String, Object> toMap();

  @SuppressWarnings("unchecked")
  public static HandleRequestDevicePromptParameters fromMap(Map<String, Object> map) {
    Object discriminator = map.get("accept");
    if (Objects.equals(discriminator, true))
      return (HandleRequestDevicePromptParameters)(Object) ConverterFunctions.fromMap(HandleRequestDevicePromptParameters.AcceptParameters.class).apply(map);
    if (Objects.equals(discriminator, false))
      return (HandleRequestDevicePromptParameters)(Object) ConverterFunctions.fromMap(HandleRequestDevicePromptParameters.CancelParameters.class).apply(map);
    throw new BiDiException("Unknown HandleRequestDevicePromptParameters discriminator '" + discriminator + "'");
  }

  private static HandleRequestDevicePromptParameters fromJson(Map<String, Object> map) {
    return fromMap(map);
  }

  public static class AcceptParameters implements HandleRequestDevicePromptParameters {

    private final String context;
    private final String prompt;
    private final boolean accept;
    private final String device;

    public AcceptParameters(String context, String prompt, boolean accept, String device) {
      this.context = Objects.requireNonNull(context, "context is required");
      this.prompt = Objects.requireNonNull(prompt, "prompt is required");
      if (!Objects.equals(accept, true)) {
        throw new BiDiException("accept must be " + true + ", got: " + accept);
      }
      this.accept = accept;
      this.device = Objects.requireNonNull(device, "device is required");
    }

    public String getContext() {
      return context;
    }

    public String getPrompt() {
      return prompt;
    }

    public boolean getAccept() {
      return accept;
    }

    public String getDevice() {
      return device;
    }

    @Override
    public Map<String, Object> toMap() {
      Map<String, Object> map = new LinkedHashMap<>();
      map.put("context", context);
      map.put("prompt", prompt);
      map.put("accept", accept);
      map.put("device", device);
      return Collections.unmodifiableMap(map);
    }

  }

  public static class CancelParameters implements HandleRequestDevicePromptParameters {

    private final String context;
    private final String prompt;
    private final boolean accept;

    public CancelParameters(String context, String prompt, boolean accept) {
      this.context = Objects.requireNonNull(context, "context is required");
      this.prompt = Objects.requireNonNull(prompt, "prompt is required");
      if (!Objects.equals(accept, false)) {
        throw new BiDiException("accept must be " + false + ", got: " + accept);
      }
      this.accept = accept;
    }

    public String getContext() {
      return context;
    }

    public String getPrompt() {
      return prompt;
    }

    public boolean getAccept() {
      return accept;
    }

    @Override
    public Map<String, Object> toMap() {
      Map<String, Object> map = new LinkedHashMap<>();
      map.put("context", context);
      map.put("prompt", prompt);
      map.put("accept", accept);
      return Collections.unmodifiableMap(map);
    }

  }
}
