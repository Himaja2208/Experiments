// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.network;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
@WarnOnUnknownFields
public class FetchTimingInfo {

  private final Number timeOrigin;
  private final Number requestTime;
  private final Number redirectStart;
  private final Number redirectEnd;
  private final Number fetchStart;
  private final Number dnsStart;
  private final Number dnsEnd;
  private final Number connectStart;
  private final Number connectEnd;
  private final Number tlsStart;
  private final Number requestStart;
  private final Number responseStart;
  private final Number responseEnd;

  public FetchTimingInfo(Number timeOrigin, Number requestTime, Number redirectStart, Number redirectEnd, Number fetchStart, Number dnsStart, Number dnsEnd, Number connectStart, Number connectEnd, Number tlsStart, Number requestStart, Number responseStart, Number responseEnd) {
    this.timeOrigin = Objects.requireNonNull(timeOrigin, "timeOrigin is required");
    this.requestTime = Objects.requireNonNull(requestTime, "requestTime is required");
    this.redirectStart = Objects.requireNonNull(redirectStart, "redirectStart is required");
    this.redirectEnd = Objects.requireNonNull(redirectEnd, "redirectEnd is required");
    this.fetchStart = Objects.requireNonNull(fetchStart, "fetchStart is required");
    this.dnsStart = Objects.requireNonNull(dnsStart, "dnsStart is required");
    this.dnsEnd = Objects.requireNonNull(dnsEnd, "dnsEnd is required");
    this.connectStart = Objects.requireNonNull(connectStart, "connectStart is required");
    this.connectEnd = Objects.requireNonNull(connectEnd, "connectEnd is required");
    this.tlsStart = Objects.requireNonNull(tlsStart, "tlsStart is required");
    this.requestStart = Objects.requireNonNull(requestStart, "requestStart is required");
    this.responseStart = Objects.requireNonNull(responseStart, "responseStart is required");
    this.responseEnd = Objects.requireNonNull(responseEnd, "responseEnd is required");
  }

  public Number getTimeOrigin() {
    return timeOrigin;
  }

  public Number getRequestTime() {
    return requestTime;
  }

  public Number getRedirectStart() {
    return redirectStart;
  }

  public Number getRedirectEnd() {
    return redirectEnd;
  }

  public Number getFetchStart() {
    return fetchStart;
  }

  public Number getDnsStart() {
    return dnsStart;
  }

  public Number getDnsEnd() {
    return dnsEnd;
  }

  public Number getConnectStart() {
    return connectStart;
  }

  public Number getConnectEnd() {
    return connectEnd;
  }

  public Number getTlsStart() {
    return tlsStart;
  }

  public Number getRequestStart() {
    return requestStart;
  }

  public Number getResponseStart() {
    return responseStart;
  }

  public Number getResponseEnd() {
    return responseEnd;
  }

}
