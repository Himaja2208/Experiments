// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.browser;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
@WarnOnUnknownFields
public class ClientWindowInfo {

  private final boolean active;
  private final String clientWindow;
  private final long height;
  private final ClientWindowInfo.State state;
  private final long width;
  private final long x;
  private final long y;

  public ClientWindowInfo(boolean active, String clientWindow, long height, ClientWindowInfo.State state, long width, long x, long y) {
    this.active = active;
    this.clientWindow = Objects.requireNonNull(clientWindow, "clientWindow is required");
    if (height < 0L || height > 9007199254740991L) {
      throw new BiDiException("height must be between 0 and 9007199254740991, got: " + height);
    }
    this.height = height;
    this.state = Objects.requireNonNull(state, "state is required");
    if (width < 0L || width > 9007199254740991L) {
      throw new BiDiException("width must be between 0 and 9007199254740991, got: " + width);
    }
    this.width = width;
    if (x < -9007199254740991L || x > 9007199254740991L) {
      throw new BiDiException("x must be between -9007199254740991 and 9007199254740991, got: " + x);
    }
    this.x = x;
    if (y < -9007199254740991L || y > 9007199254740991L) {
      throw new BiDiException("y must be between -9007199254740991 and 9007199254740991, got: " + y);
    }
    this.y = y;
  }

  public boolean getActive() {
    return active;
  }

  public String getClientWindow() {
    return clientWindow;
  }

  public long getHeight() {
    return height;
  }

  public ClientWindowInfo.State getState() {
    return state;
  }

  public long getWidth() {
    return width;
  }

  public long getX() {
    return x;
  }

  public long getY() {
    return y;
  }


  public enum State {

    FULLSCREEN("fullscreen"),
    MAXIMIZED("maximized"),
    MINIMIZED("minimized"),
    NORMAL("normal");

    private final String value;

    State(String value) {
      this.value = value;
    }

    public static State fromJson(String s) {
      for (State e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown State value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }
}
