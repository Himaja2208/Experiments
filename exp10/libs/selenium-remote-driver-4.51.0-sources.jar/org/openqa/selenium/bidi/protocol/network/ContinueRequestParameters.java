// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.network;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class ContinueRequestParameters {

  private final String request;
  private Optional<BytesValue> body;
  private Optional<java.util.List<CookieHeader>> cookies;
  private Optional<java.util.List<Header>> headers;
  private Optional<String> method;
  private Optional<String> url;

  public ContinueRequestParameters(String request) {
    this.request = Objects.requireNonNull(request, "request is required");
    this.body = Optional.empty();
    this.cookies = Optional.empty();
    this.headers = Optional.empty();
    this.method = Optional.empty();
    this.url = Optional.empty();
  }

  ContinueRequestParameters(String request, Optional<BytesValue> body, Optional<java.util.List<CookieHeader>> cookies, Optional<java.util.List<Header>> headers, Optional<String> method, Optional<String> url) {
    this.request = Objects.requireNonNull(request, "request is required");
    this.body = body != null ? body : Optional.empty();
    this.cookies = cookies != null ? cookies : Optional.empty();
    this.headers = headers != null ? headers : Optional.empty();
    this.method = method != null ? method : Optional.empty();
    this.url = url != null ? url : Optional.empty();
  }

  public ContinueRequestParameters setBody(BytesValue body) {
    this.body = Optional.ofNullable(body);
    return this;
  }

  public ContinueRequestParameters setCookies(java.util.List<CookieHeader> cookies) {
    this.cookies = Optional.ofNullable(cookies);
    return this;
  }

  public ContinueRequestParameters setHeaders(java.util.List<Header> headers) {
    this.headers = Optional.ofNullable(headers);
    return this;
  }

  public ContinueRequestParameters setMethod(String method) {
    this.method = Optional.ofNullable(method);
    return this;
  }

  public ContinueRequestParameters setUrl(String url) {
    this.url = Optional.ofNullable(url);
    return this;
  }

  public String getRequest() {
    return request;
  }

  public Optional<BytesValue> getBody() {
    return body;
  }

  public Optional<java.util.List<CookieHeader>> getCookies() {
    return cookies;
  }

  public Optional<java.util.List<Header>> getHeaders() {
    return headers;
  }

  public Optional<String> getMethod() {
    return method;
  }

  public Optional<String> getUrl() {
    return url;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("request", request);
    body.ifPresent(v -> map.put("body", v.toMap()));
    cookies.ifPresent(v -> map.put("cookies", v.stream().map(e -> java.util.Objects.requireNonNull(e, "cookies element must not be null").toMap()).collect(java.util.stream.Collectors.toList())));
    headers.ifPresent(v -> map.put("headers", v.stream().map(e -> java.util.Objects.requireNonNull(e, "headers element must not be null").toMap()).collect(java.util.stream.Collectors.toList())));
    method.ifPresent(v -> map.put("method", v));
    url.ifPresent(v -> map.put("url", v));
    return Collections.unmodifiableMap(map);
  }

}
