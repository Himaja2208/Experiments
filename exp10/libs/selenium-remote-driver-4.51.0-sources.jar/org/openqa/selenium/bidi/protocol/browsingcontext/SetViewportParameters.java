// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.browsingcontext;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class SetViewportParameters {

  private Optional<String> context;
  private Optional<Viewport> viewport;
  private boolean viewportSet;
  private Optional<Number> devicePixelRatio;
  private boolean devicePixelRatioSet;
  private Optional<java.util.List<String>> userContexts;

  public SetViewportParameters() {
    this.context = Optional.empty();
    this.viewport = Optional.empty();
    this.devicePixelRatio = Optional.empty();
    this.userContexts = Optional.empty();
  }

  SetViewportParameters(Optional<String> context, Optional<Viewport> viewport, Optional<Number> devicePixelRatio, Optional<java.util.List<String>> userContexts) {
    this.context = context != null ? context : Optional.empty();
    this.viewport = viewport != null ? viewport : Optional.empty();
    this.viewportSet = this.viewport.isPresent();
    this.devicePixelRatio = devicePixelRatio != null ? devicePixelRatio : Optional.empty();
    this.devicePixelRatioSet = this.devicePixelRatio.isPresent();
    this.userContexts = userContexts != null ? userContexts : Optional.empty();
  }

  public SetViewportParameters setContext(String context) {
    this.context = Optional.ofNullable(context);
    return this;
  }

  public SetViewportParameters setViewport(Viewport viewport) {
    this.viewport = Optional.ofNullable(viewport);
    this.viewportSet = true;
    return this;
  }

  public SetViewportParameters setDevicePixelRatio(Number devicePixelRatio) {
    this.devicePixelRatio = Optional.ofNullable(devicePixelRatio);
    this.devicePixelRatioSet = true;
    return this;
  }

  public SetViewportParameters setUserContexts(java.util.List<String> userContexts) {
    this.userContexts = Optional.ofNullable(userContexts);
    return this;
  }

  public Optional<String> getContext() {
    return context;
  }

  public Optional<Viewport> getViewport() {
    return viewport;
  }

  public Optional<Number> getDevicePixelRatio() {
    return devicePixelRatio;
  }

  public Optional<java.util.List<String>> getUserContexts() {
    return userContexts;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    context.ifPresent(v -> map.put("context", v));
    if (viewportSet) {
      map.put("viewport", viewport.isPresent() ? viewport.get().toMap() : null);
    }
    if (devicePixelRatioSet) {
      map.put("devicePixelRatio", devicePixelRatio.isPresent() ? devicePixelRatio.get() : null);
    }
    userContexts.ifPresent(v -> map.put("userContexts", v.stream().map(e -> java.util.Objects.requireNonNull(e, "userContexts element must not be null")).collect(java.util.stream.Collectors.toList())));
    return Collections.unmodifiableMap(map);
  }

}
