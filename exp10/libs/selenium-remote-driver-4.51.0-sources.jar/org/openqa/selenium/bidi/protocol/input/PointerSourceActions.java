// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.input;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class PointerSourceActions implements SourceActions {

  private final String type;
  private final String id;
  private Optional<PointerParameters> parameters;
  private final java.util.List<PointerSourceAction> actions;

  public PointerSourceActions(String type, String id, java.util.List<PointerSourceAction> actions) {
    if (!Objects.equals(type, "pointer")) {
      throw new BiDiException("type must be " + "pointer" + ", got: " + type);
    }
    this.type = Objects.requireNonNull(type, "type is required");
    this.id = Objects.requireNonNull(id, "id is required");
    this.actions = Objects.requireNonNull(actions, "actions is required");
    this.parameters = Optional.empty();
  }

  PointerSourceActions(String type, String id, Optional<PointerParameters> parameters, java.util.List<PointerSourceAction> actions) {
    if (!Objects.equals(type, "pointer")) {
      throw new BiDiException("type must be " + "pointer" + ", got: " + type);
    }
    this.type = Objects.requireNonNull(type, "type is required");
    this.id = Objects.requireNonNull(id, "id is required");
    this.parameters = parameters != null ? parameters : Optional.empty();
    this.actions = Objects.requireNonNull(actions, "actions is required");
  }

  public PointerSourceActions setParameters(PointerParameters parameters) {
    this.parameters = Optional.ofNullable(parameters);
    return this;
  }

  public String getType() {
    return type;
  }

  public String getId() {
    return id;
  }

  public Optional<PointerParameters> getParameters() {
    return parameters;
  }

  public java.util.List<PointerSourceAction> getActions() {
    return actions;
  }

  @Override
  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("type", type);
    map.put("id", id);
    map.put("actions", actions.stream().map(e -> java.util.Objects.requireNonNull(e, "actions element must not be null").toMap()).collect(java.util.stream.Collectors.toList()));
    parameters.ifPresent(v -> map.put("parameters", v.toMap()));
    return Collections.unmodifiableMap(map);
  }

}
