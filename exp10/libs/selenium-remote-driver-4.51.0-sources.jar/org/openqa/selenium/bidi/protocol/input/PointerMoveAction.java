// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.input;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class PointerMoveAction implements PointerSourceAction {

  private final String type;
  private final Number x;
  private final Number y;
  private Optional<Long> duration;
  private Optional<Origin> origin;
  private Optional<Long> width;
  private Optional<Long> height;
  private Optional<Number> pressure;
  private Optional<Number> tangentialPressure;
  private Optional<Long> twist;
  private Optional<Number> altitudeAngle;
  private Optional<Number> azimuthAngle;

  public PointerMoveAction(String type, Number x, Number y) {
    if (!Objects.equals(type, "pointerMove")) {
      throw new BiDiException("type must be " + "pointerMove" + ", got: " + type);
    }
    this.type = Objects.requireNonNull(type, "type is required");
    this.x = Objects.requireNonNull(x, "x is required");
    this.y = Objects.requireNonNull(y, "y is required");
    this.duration = Optional.empty();
    this.origin = Optional.empty();
    this.width = Optional.empty();
    this.height = Optional.empty();
    this.pressure = Optional.empty();
    this.tangentialPressure = Optional.empty();
    this.twist = Optional.empty();
    this.altitudeAngle = Optional.empty();
    this.azimuthAngle = Optional.empty();
  }

  PointerMoveAction(String type, Number x, Number y, Optional<Long> duration, Optional<Origin> origin, Optional<Long> width, Optional<Long> height, Optional<Number> pressure, Optional<Number> tangentialPressure, Optional<Long> twist, Optional<Number> altitudeAngle, Optional<Number> azimuthAngle) {
    if (!Objects.equals(type, "pointerMove")) {
      throw new BiDiException("type must be " + "pointerMove" + ", got: " + type);
    }
    this.type = Objects.requireNonNull(type, "type is required");
    this.x = Objects.requireNonNull(x, "x is required");
    this.y = Objects.requireNonNull(y, "y is required");
    if (duration != null && duration.isPresent() && (duration.get() < 0L || duration.get() > 9007199254740991L)) {
      throw new BiDiException("duration must be between 0 and 9007199254740991, got: " + duration.get());
    }
    this.duration = duration != null ? duration : Optional.empty();
    this.origin = origin != null ? origin : Optional.empty();
    if (width != null && width.isPresent() && (width.get() < 0L || width.get() > 9007199254740991L)) {
      throw new BiDiException("width must be between 0 and 9007199254740991, got: " + width.get());
    }
    this.width = width != null ? width : Optional.empty();
    if (height != null && height.isPresent() && (height.get() < 0L || height.get() > 9007199254740991L)) {
      throw new BiDiException("height must be between 0 and 9007199254740991, got: " + height.get());
    }
    this.height = height != null ? height : Optional.empty();
    this.pressure = pressure != null ? pressure : Optional.empty();
    this.tangentialPressure = tangentialPressure != null ? tangentialPressure : Optional.empty();
    this.twist = twist != null ? twist : Optional.empty();
    this.altitudeAngle = altitudeAngle != null ? altitudeAngle : Optional.empty();
    this.azimuthAngle = azimuthAngle != null ? azimuthAngle : Optional.empty();
  }

  public PointerMoveAction setDuration(Long duration) {
    if (duration != null && (duration < 0L || duration > 9007199254740991L)) {
      throw new BiDiException("duration must be between 0 and 9007199254740991, got: " + duration);
    }
    this.duration = Optional.ofNullable(duration);
    return this;
  }

  public PointerMoveAction setOrigin(Origin origin) {
    this.origin = Optional.ofNullable(origin);
    return this;
  }

  public PointerMoveAction setWidth(Long width) {
    if (width != null && (width < 0L || width > 9007199254740991L)) {
      throw new BiDiException("width must be between 0 and 9007199254740991, got: " + width);
    }
    this.width = Optional.ofNullable(width);
    return this;
  }

  public PointerMoveAction setHeight(Long height) {
    if (height != null && (height < 0L || height > 9007199254740991L)) {
      throw new BiDiException("height must be between 0 and 9007199254740991, got: " + height);
    }
    this.height = Optional.ofNullable(height);
    return this;
  }

  public PointerMoveAction setPressure(Number pressure) {
    this.pressure = Optional.ofNullable(pressure);
    return this;
  }

  public PointerMoveAction setTangentialPressure(Number tangentialPressure) {
    this.tangentialPressure = Optional.ofNullable(tangentialPressure);
    return this;
  }

  public PointerMoveAction setTwist(Long twist) {
    this.twist = Optional.ofNullable(twist);
    return this;
  }

  public PointerMoveAction setAltitudeAngle(Number altitudeAngle) {
    this.altitudeAngle = Optional.ofNullable(altitudeAngle);
    return this;
  }

  public PointerMoveAction setAzimuthAngle(Number azimuthAngle) {
    this.azimuthAngle = Optional.ofNullable(azimuthAngle);
    return this;
  }

  public String getType() {
    return type;
  }

  public Number getX() {
    return x;
  }

  public Number getY() {
    return y;
  }

  public Optional<Long> getDuration() {
    return duration;
  }

  public Optional<Origin> getOrigin() {
    return origin;
  }

  public Optional<Long> getWidth() {
    return width;
  }

  public Optional<Long> getHeight() {
    return height;
  }

  public Optional<Number> getPressure() {
    return pressure;
  }

  public Optional<Number> getTangentialPressure() {
    return tangentialPressure;
  }

  public Optional<Long> getTwist() {
    return twist;
  }

  public Optional<Number> getAltitudeAngle() {
    return altitudeAngle;
  }

  public Optional<Number> getAzimuthAngle() {
    return azimuthAngle;
  }

  @Override
  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("type", type);
    map.put("x", x);
    map.put("y", y);
    duration.ifPresent(v -> map.put("duration", v));
    origin.ifPresent(v -> map.put("origin", v.toWireValue()));
    width.ifPresent(v -> map.put("width", v));
    height.ifPresent(v -> map.put("height", v));
    pressure.ifPresent(v -> map.put("pressure", v));
    tangentialPressure.ifPresent(v -> map.put("tangentialPressure", v));
    twist.ifPresent(v -> map.put("twist", v));
    altitudeAngle.ifPresent(v -> map.put("altitudeAngle", v));
    azimuthAngle.ifPresent(v -> map.put("azimuthAngle", v));
    return Collections.unmodifiableMap(map);
  }

}
