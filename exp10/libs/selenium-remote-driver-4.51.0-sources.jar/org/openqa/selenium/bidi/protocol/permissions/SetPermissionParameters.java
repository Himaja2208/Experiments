// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.permissions;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class SetPermissionParameters {

  private final PermissionDescriptor descriptor;
  private final PermissionState state;
  private final String origin;
  private Optional<String> embeddedOrigin;
  private Optional<String> userContext;

  public SetPermissionParameters(PermissionDescriptor descriptor, PermissionState state, String origin) {
    this.descriptor = Objects.requireNonNull(descriptor, "descriptor is required");
    this.state = Objects.requireNonNull(state, "state is required");
    this.origin = Objects.requireNonNull(origin, "origin is required");
    this.embeddedOrigin = Optional.empty();
    this.userContext = Optional.empty();
  }

  SetPermissionParameters(PermissionDescriptor descriptor, PermissionState state, String origin, Optional<String> embeddedOrigin, Optional<String> userContext) {
    this.descriptor = Objects.requireNonNull(descriptor, "descriptor is required");
    this.state = Objects.requireNonNull(state, "state is required");
    this.origin = Objects.requireNonNull(origin, "origin is required");
    this.embeddedOrigin = embeddedOrigin != null ? embeddedOrigin : Optional.empty();
    this.userContext = userContext != null ? userContext : Optional.empty();
  }

  public SetPermissionParameters setEmbeddedOrigin(String embeddedOrigin) {
    this.embeddedOrigin = Optional.ofNullable(embeddedOrigin);
    return this;
  }

  public SetPermissionParameters setUserContext(String userContext) {
    this.userContext = Optional.ofNullable(userContext);
    return this;
  }

  public PermissionDescriptor getDescriptor() {
    return descriptor;
  }

  public PermissionState getState() {
    return state;
  }

  public String getOrigin() {
    return origin;
  }

  public Optional<String> getEmbeddedOrigin() {
    return embeddedOrigin;
  }

  public Optional<String> getUserContext() {
    return userContext;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("descriptor", descriptor.toMap());
    map.put("state", state.toWireValue());
    map.put("origin", origin);
    embeddedOrigin.ifPresent(v -> map.put("embeddedOrigin", v));
    userContext.ifPresent(v -> map.put("userContext", v));
    return Collections.unmodifiableMap(map);
  }

}
