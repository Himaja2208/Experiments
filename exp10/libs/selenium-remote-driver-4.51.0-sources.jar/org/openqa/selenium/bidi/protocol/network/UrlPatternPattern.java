// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.network;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class UrlPatternPattern implements UrlPattern {

  private final String type;
  private Optional<String> protocol;
  private Optional<String> hostname;
  private Optional<String> port;
  private Optional<String> pathname;
  private Optional<String> search;

  public UrlPatternPattern(String type) {
    if (!Objects.equals(type, "pattern")) {
      throw new BiDiException("type must be " + "pattern" + ", got: " + type);
    }
    this.type = Objects.requireNonNull(type, "type is required");
    this.protocol = Optional.empty();
    this.hostname = Optional.empty();
    this.port = Optional.empty();
    this.pathname = Optional.empty();
    this.search = Optional.empty();
  }

  UrlPatternPattern(String type, Optional<String> protocol, Optional<String> hostname, Optional<String> port, Optional<String> pathname, Optional<String> search) {
    if (!Objects.equals(type, "pattern")) {
      throw new BiDiException("type must be " + "pattern" + ", got: " + type);
    }
    this.type = Objects.requireNonNull(type, "type is required");
    this.protocol = protocol != null ? protocol : Optional.empty();
    this.hostname = hostname != null ? hostname : Optional.empty();
    this.port = port != null ? port : Optional.empty();
    this.pathname = pathname != null ? pathname : Optional.empty();
    this.search = search != null ? search : Optional.empty();
  }

  public UrlPatternPattern setProtocol(String protocol) {
    this.protocol = Optional.ofNullable(protocol);
    return this;
  }

  public UrlPatternPattern setHostname(String hostname) {
    this.hostname = Optional.ofNullable(hostname);
    return this;
  }

  public UrlPatternPattern setPort(String port) {
    this.port = Optional.ofNullable(port);
    return this;
  }

  public UrlPatternPattern setPathname(String pathname) {
    this.pathname = Optional.ofNullable(pathname);
    return this;
  }

  public UrlPatternPattern setSearch(String search) {
    this.search = Optional.ofNullable(search);
    return this;
  }

  public String getType() {
    return type;
  }

  public Optional<String> getProtocol() {
    return protocol;
  }

  public Optional<String> getHostname() {
    return hostname;
  }

  public Optional<String> getPort() {
    return port;
  }

  public Optional<String> getPathname() {
    return pathname;
  }

  public Optional<String> getSearch() {
    return search;
  }

  @Override
  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("type", type);
    protocol.ifPresent(v -> map.put("protocol", v));
    hostname.ifPresent(v -> map.put("hostname", v));
    port.ifPresent(v -> map.put("port", v));
    pathname.ifPresent(v -> map.put("pathname", v));
    search.ifPresent(v -> map.put("search", v));
    return Collections.unmodifiableMap(map);
  }

}
