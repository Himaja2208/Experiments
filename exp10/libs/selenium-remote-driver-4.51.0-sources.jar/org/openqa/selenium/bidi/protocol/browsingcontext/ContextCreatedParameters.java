// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.browsingcontext;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
@WarnOnUnknownFields
public class ContextCreatedParameters {

  private final java.util.List<Info> children;
  private final String clientWindow;
  private final String context;
  private final String originalOpener;
  private final String url;
  private final String userContext;
  private final Optional<String> parent;
  private final boolean parentSet;
  private final Optional<Boolean> hasPlannedNavigation;

  ContextCreatedParameters(java.util.@Nullable List<Info> children, String clientWindow, String context, @Nullable String originalOpener, String url, String userContext, Optional<String> parent, Optional<Boolean> hasPlannedNavigation) {
    this.children = children;
    this.clientWindow = Objects.requireNonNull(clientWindow, "clientWindow is required");
    this.context = Objects.requireNonNull(context, "context is required");
    this.originalOpener = originalOpener;
    this.url = Objects.requireNonNull(url, "url is required");
    this.userContext = Objects.requireNonNull(userContext, "userContext is required");
    this.parent = parent != null ? parent : Optional.empty();
    this.parentSet = this.parent.isPresent();
    this.hasPlannedNavigation = hasPlannedNavigation != null ? hasPlannedNavigation : Optional.empty();
  }

  public java.util.List<Info> getChildren() {
    return children;
  }

  public String getClientWindow() {
    return clientWindow;
  }

  public String getContext() {
    return context;
  }

  public String getOriginalOpener() {
    return originalOpener;
  }

  public String getUrl() {
    return url;
  }

  public String getUserContext() {
    return userContext;
  }

  public Optional<String> getParent() {
    return parent;
  }

  public Optional<Boolean> getHasPlannedNavigation() {
    return hasPlannedNavigation;
  }

}
