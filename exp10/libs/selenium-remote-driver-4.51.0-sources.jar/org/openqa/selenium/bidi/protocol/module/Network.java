// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.module;

import org.jetbrains.annotations.ApiStatus;
import org.openqa.selenium.Beta;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.bidi.Command;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.bidi.Event;
import org.openqa.selenium.bidi.Module;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
@SuppressWarnings("unchecked")
public class Network extends Module {

  public static final Event<org.openqa.selenium.bidi.protocol.network.AuthRequiredParameters> AUTH_REQUIRED =
      new Event<>("network.authRequired", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.network.AuthRequiredParameters.class));

  public static final Event<org.openqa.selenium.bidi.protocol.network.BeforeRequestSentParameters> BEFORE_REQUEST_SENT =
      new Event<>("network.beforeRequestSent", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.network.BeforeRequestSentParameters.class));

  public static final Event<org.openqa.selenium.bidi.protocol.network.FetchErrorParameters> FETCH_ERROR =
      new Event<>("network.fetchError", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.network.FetchErrorParameters.class));

  public static final Event<org.openqa.selenium.bidi.protocol.network.ResponseCompletedParameters> RESPONSE_COMPLETED =
      new Event<>("network.responseCompleted", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.network.ResponseCompletedParameters.class));

  public static final Event<org.openqa.selenium.bidi.protocol.network.ResponseStartedParameters> RESPONSE_STARTED =
      new Event<>("network.responseStarted", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.network.ResponseStartedParameters.class));

  public Network(WebDriver driver) {
    super(driver);
  }

  public org.openqa.selenium.bidi.protocol.network.AddDataCollectorResult addDataCollector(org.openqa.selenium.bidi.protocol.network.AddDataCollectorParameters params) {
    return send(new Command<>("network.addDataCollector", params.toMap(), org.openqa.selenium.bidi.protocol.network.AddDataCollectorResult.class));
  }

  public org.openqa.selenium.bidi.protocol.network.AddInterceptResult addIntercept(org.openqa.selenium.bidi.protocol.network.AddInterceptParameters params) {
    return send(new Command<>("network.addIntercept", params.toMap(), org.openqa.selenium.bidi.protocol.network.AddInterceptResult.class));
  }

  public void continueRequest(org.openqa.selenium.bidi.protocol.network.ContinueRequestParameters params) {
    send(new Command<>("network.continueRequest", params.toMap()));
  }

  public void continueResponse(org.openqa.selenium.bidi.protocol.network.ContinueResponseParameters params) {
    send(new Command<>("network.continueResponse", params.toMap()));
  }

  public void continueWithAuth(org.openqa.selenium.bidi.protocol.network.ContinueWithAuthParameters params) {
    send(new Command<>("network.continueWithAuth", params.toMap()));
  }

  public void disownData(org.openqa.selenium.bidi.protocol.network.DisownDataParameters params) {
    send(new Command<>("network.disownData", params.toMap()));
  }

  public void failRequest(org.openqa.selenium.bidi.protocol.network.FailRequestParameters params) {
    send(new Command<>("network.failRequest", params.toMap()));
  }

  public org.openqa.selenium.bidi.protocol.network.GetDataResult getData(org.openqa.selenium.bidi.protocol.network.GetDataParameters params) {
    return send(new Command<>("network.getData", params.toMap(), org.openqa.selenium.bidi.protocol.network.GetDataResult.class));
  }

  public void provideResponse(org.openqa.selenium.bidi.protocol.network.ProvideResponseParameters params) {
    send(new Command<>("network.provideResponse", params.toMap()));
  }

  public void removeDataCollector(org.openqa.selenium.bidi.protocol.network.RemoveDataCollectorParameters params) {
    send(new Command<>("network.removeDataCollector", params.toMap()));
  }

  public void removeIntercept(org.openqa.selenium.bidi.protocol.network.RemoveInterceptParameters params) {
    send(new Command<>("network.removeIntercept", params.toMap()));
  }

  public void setCacheBehavior(org.openqa.selenium.bidi.protocol.network.SetCacheBehaviorParameters params) {
    send(new Command<>("network.setCacheBehavior", params.toMap()));
  }

  public void setExtraHeaders(org.openqa.selenium.bidi.protocol.network.SetExtraHeadersParameters params) {
    send(new Command<>("network.setExtraHeaders", params.toMap()));
  }

}
