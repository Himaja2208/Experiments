// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.module;

import org.jetbrains.annotations.ApiStatus;
import org.openqa.selenium.Beta;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.bidi.Command;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.bidi.Event;
import org.openqa.selenium.bidi.Module;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
@SuppressWarnings("unchecked")
public class Script extends Module {

  public static final Event<org.openqa.selenium.bidi.protocol.script.MessageParameters> MESSAGE =
      new Event<>("script.message", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.script.MessageParameters.class));

  public static final Event<org.openqa.selenium.bidi.protocol.script.RealmInfo> REALM_CREATED =
      new Event<>("script.realmCreated", org.openqa.selenium.bidi.protocol.script.RealmInfo::fromMap);

  public static final Event<org.openqa.selenium.bidi.protocol.script.RealmDestroyedParameters> REALM_DESTROYED =
      new Event<>("script.realmDestroyed", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.script.RealmDestroyedParameters.class));

  public Script(WebDriver driver) {
    super(driver);
  }

  public org.openqa.selenium.bidi.protocol.script.AddPreloadScriptResult addPreloadScript(org.openqa.selenium.bidi.protocol.script.AddPreloadScriptParameters params) {
    return send(new Command<>("script.addPreloadScript", params.toMap(), org.openqa.selenium.bidi.protocol.script.AddPreloadScriptResult.class));
  }

  public org.openqa.selenium.bidi.protocol.script.EvaluateResult callFunction(org.openqa.selenium.bidi.protocol.script.CallFunctionParameters params) {
    return send(new Command<>("script.callFunction", params.toMap(), input -> {
      @SuppressWarnings("unchecked")
      java.util.Map<String, Object> m = (java.util.Map<String, Object>) input;
      return org.openqa.selenium.bidi.protocol.script.EvaluateResult.fromMap(m);
    }));
  }

  public void disown(org.openqa.selenium.bidi.protocol.script.DisownParameters params) {
    send(new Command<>("script.disown", params.toMap()));
  }

  public org.openqa.selenium.bidi.protocol.script.EvaluateResult evaluate(org.openqa.selenium.bidi.protocol.script.EvaluateParameters params) {
    return send(new Command<>("script.evaluate", params.toMap(), input -> {
      @SuppressWarnings("unchecked")
      java.util.Map<String, Object> m = (java.util.Map<String, Object>) input;
      return org.openqa.selenium.bidi.protocol.script.EvaluateResult.fromMap(m);
    }));
  }

  public org.openqa.selenium.bidi.protocol.script.GetRealmsResult getRealms(org.openqa.selenium.bidi.protocol.script.GetRealmsParameters params) {
    return send(new Command<>("script.getRealms", params.toMap(), org.openqa.selenium.bidi.protocol.script.GetRealmsResult.class));
  }

  public void removePreloadScript(org.openqa.selenium.bidi.protocol.script.RemovePreloadScriptParameters params) {
    send(new Command<>("script.removePreloadScript", params.toMap()));
  }

}
