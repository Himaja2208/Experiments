// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.browsingcontext;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class LocateNodesParameters {

  private final String context;
  private final Locator locator;
  private Optional<Long> maxNodeCount;
  private Optional<org.openqa.selenium.bidi.protocol.script.SerializationOptions> serializationOptions;
  private Optional<java.util.List<org.openqa.selenium.bidi.protocol.script.SharedReference>> startNodes;

  public LocateNodesParameters(String context, Locator locator) {
    this.context = Objects.requireNonNull(context, "context is required");
    this.locator = Objects.requireNonNull(locator, "locator is required");
    this.maxNodeCount = Optional.empty();
    this.serializationOptions = Optional.empty();
    this.startNodes = Optional.empty();
  }

  LocateNodesParameters(String context, Locator locator, Optional<Long> maxNodeCount, Optional<org.openqa.selenium.bidi.protocol.script.SerializationOptions> serializationOptions, Optional<java.util.List<org.openqa.selenium.bidi.protocol.script.SharedReference>> startNodes) {
    this.context = Objects.requireNonNull(context, "context is required");
    this.locator = Objects.requireNonNull(locator, "locator is required");
    if (maxNodeCount != null && maxNodeCount.isPresent() && (maxNodeCount.get() < 0L || maxNodeCount.get() > 9007199254740991L)) {
      throw new BiDiException("maxNodeCount must be between 0 and 9007199254740991, got: " + maxNodeCount.get());
    }
    this.maxNodeCount = maxNodeCount != null ? maxNodeCount : Optional.empty();
    this.serializationOptions = serializationOptions != null ? serializationOptions : Optional.empty();
    this.startNodes = startNodes != null ? startNodes : Optional.empty();
  }

  public LocateNodesParameters setMaxNodeCount(Long maxNodeCount) {
    if (maxNodeCount != null && (maxNodeCount < 0L || maxNodeCount > 9007199254740991L)) {
      throw new BiDiException("maxNodeCount must be between 0 and 9007199254740991, got: " + maxNodeCount);
    }
    this.maxNodeCount = Optional.ofNullable(maxNodeCount);
    return this;
  }

  public LocateNodesParameters setSerializationOptions(org.openqa.selenium.bidi.protocol.script.SerializationOptions serializationOptions) {
    this.serializationOptions = Optional.ofNullable(serializationOptions);
    return this;
  }

  public LocateNodesParameters setStartNodes(java.util.List<org.openqa.selenium.bidi.protocol.script.SharedReference> startNodes) {
    this.startNodes = Optional.ofNullable(startNodes);
    return this;
  }

  public String getContext() {
    return context;
  }

  public Locator getLocator() {
    return locator;
  }

  public Optional<Long> getMaxNodeCount() {
    return maxNodeCount;
  }

  public Optional<org.openqa.selenium.bidi.protocol.script.SerializationOptions> getSerializationOptions() {
    return serializationOptions;
  }

  public Optional<java.util.List<org.openqa.selenium.bidi.protocol.script.SharedReference>> getStartNodes() {
    return startNodes;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("context", context);
    map.put("locator", locator.toMap());
    maxNodeCount.ifPresent(v -> map.put("maxNodeCount", v));
    serializationOptions.ifPresent(v -> map.put("serializationOptions", v.toMap()));
    startNodes.ifPresent(v -> map.put("startNodes", v.stream().map(e -> java.util.Objects.requireNonNull(e, "startNodes element must not be null").toMap()).collect(java.util.stream.Collectors.toList())));
    return Collections.unmodifiableMap(map);
  }

}
