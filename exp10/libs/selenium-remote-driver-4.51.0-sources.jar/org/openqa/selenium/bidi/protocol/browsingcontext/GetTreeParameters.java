// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.browsingcontext;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class GetTreeParameters {

  private Optional<Long> maxDepth;
  private Optional<String> root;

  public GetTreeParameters() {
    this.maxDepth = Optional.empty();
    this.root = Optional.empty();
  }

  GetTreeParameters(Optional<Long> maxDepth, Optional<String> root) {
    if (maxDepth != null && maxDepth.isPresent() && (maxDepth.get() < 0L || maxDepth.get() > 9007199254740991L)) {
      throw new BiDiException("maxDepth must be between 0 and 9007199254740991, got: " + maxDepth.get());
    }
    this.maxDepth = maxDepth != null ? maxDepth : Optional.empty();
    this.root = root != null ? root : Optional.empty();
  }

  public GetTreeParameters setMaxDepth(Long maxDepth) {
    if (maxDepth != null && (maxDepth < 0L || maxDepth > 9007199254740991L)) {
      throw new BiDiException("maxDepth must be between 0 and 9007199254740991, got: " + maxDepth);
    }
    this.maxDepth = Optional.ofNullable(maxDepth);
    return this;
  }

  public GetTreeParameters setRoot(String root) {
    this.root = Optional.ofNullable(root);
    return this;
  }

  public Optional<Long> getMaxDepth() {
    return maxDepth;
  }

  public Optional<String> getRoot() {
    return root;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    maxDepth.ifPresent(v -> map.put("maxDepth", v));
    root.ifPresent(v -> map.put("root", v));
    return Collections.unmodifiableMap(map);
  }

}
