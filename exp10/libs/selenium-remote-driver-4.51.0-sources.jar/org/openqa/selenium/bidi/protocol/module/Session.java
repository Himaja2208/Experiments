// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.module;

import org.jetbrains.annotations.ApiStatus;
import org.openqa.selenium.Beta;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.bidi.Command;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.bidi.Event;
import org.openqa.selenium.bidi.Module;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
@SuppressWarnings("unchecked")
public class Session extends Module {

  public Session(WebDriver driver) {
    super(driver);
  }

  public void end() {
    send(new Command<>("session.end", java.util.Collections.emptyMap()));
  }

  public org.openqa.selenium.bidi.protocol.session.NewResult new_(org.openqa.selenium.bidi.protocol.session.NewParameters params) {
    return send(new Command<>("session.new", params.toMap(), org.openqa.selenium.bidi.protocol.session.NewResult.class));
  }

  public org.openqa.selenium.bidi.protocol.session.StatusResult status() {
    return send(new Command<>("session.status", java.util.Collections.emptyMap(), org.openqa.selenium.bidi.protocol.session.StatusResult.class));
  }

  public org.openqa.selenium.bidi.protocol.session.SubscribeResult subscribe(org.openqa.selenium.bidi.protocol.session.SubscribeParameters params) {
    return send(new Command<>("session.subscribe", params.toMap(), org.openqa.selenium.bidi.protocol.session.SubscribeResult.class));
  }

  public void unsubscribe(org.openqa.selenium.bidi.protocol.session.UnsubscribeParameters params) {
    send(new Command<>("session.unsubscribe", params.toMap()));
  }

}
