// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.module;

import org.jetbrains.annotations.ApiStatus;
import org.openqa.selenium.Beta;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.bidi.Command;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.bidi.Event;
import org.openqa.selenium.bidi.Module;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
@SuppressWarnings("unchecked")
public class Browser extends Module {

  public Browser(WebDriver driver) {
    super(driver);
  }

  public void close() {
    send(new Command<>("browser.close", java.util.Collections.emptyMap()));
  }

  public org.openqa.selenium.bidi.protocol.browser.UserContextInfo createUserContext(org.openqa.selenium.bidi.protocol.browser.CreateUserContextParameters params) {
    return send(new Command<>("browser.createUserContext", params.toMap(), org.openqa.selenium.bidi.protocol.browser.UserContextInfo.class));
  }

  public org.openqa.selenium.bidi.protocol.browser.GetClientWindowsResult getClientWindows() {
    return send(new Command<>("browser.getClientWindows", java.util.Collections.emptyMap(), org.openqa.selenium.bidi.protocol.browser.GetClientWindowsResult.class));
  }

  public org.openqa.selenium.bidi.protocol.browser.GetUserContextsResult getUserContexts() {
    return send(new Command<>("browser.getUserContexts", java.util.Collections.emptyMap(), org.openqa.selenium.bidi.protocol.browser.GetUserContextsResult.class));
  }

  public void removeUserContext(org.openqa.selenium.bidi.protocol.browser.RemoveUserContextParameters params) {
    send(new Command<>("browser.removeUserContext", params.toMap()));
  }

  public org.openqa.selenium.bidi.protocol.browser.ClientWindowInfo setClientWindowState(org.openqa.selenium.bidi.protocol.browser.SetClientWindowStateParameters params) {
    return send(new Command<>("browser.setClientWindowState", params.toMap(), org.openqa.selenium.bidi.protocol.browser.ClientWindowInfo.class));
  }

  public void setDownloadBehavior(org.openqa.selenium.bidi.protocol.browser.SetDownloadBehaviorParameters params) {
    send(new Command<>("browser.setDownloadBehavior", params.toMap()));
  }

}
