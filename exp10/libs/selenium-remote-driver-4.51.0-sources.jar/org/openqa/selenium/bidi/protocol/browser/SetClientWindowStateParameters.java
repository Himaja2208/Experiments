// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.browser;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public interface SetClientWindowStateParameters {

  Map<String, Object> toMap();

  @SuppressWarnings("unchecked")
  public static SetClientWindowStateParameters fromMap(Map<String, Object> map) {
    Object discriminator = map.get("state");
    if ("normal".equals(discriminator))
      return (SetClientWindowStateParameters)(Object) ConverterFunctions.fromMap(SetClientWindowStateParameters.ClientWindowRectState.class).apply(map);
    return (SetClientWindowStateParameters)(Object) ConverterFunctions.fromMap(SetClientWindowStateParameters.ClientWindowNamedState.class).apply(map);
  }

  private static SetClientWindowStateParameters fromJson(Map<String, Object> map) {
    return fromMap(map);
  }

  public static class ClientWindowNamedState implements SetClientWindowStateParameters {

    private final String clientWindow;
    private final SetClientWindowStateParameters.ClientWindowNamedState.State state;

    public ClientWindowNamedState(String clientWindow, SetClientWindowStateParameters.ClientWindowNamedState.State state) {
      this.clientWindow = Objects.requireNonNull(clientWindow, "clientWindow is required");
      this.state = Objects.requireNonNull(state, "state is required");
    }

    public String getClientWindow() {
      return clientWindow;
    }

    public SetClientWindowStateParameters.ClientWindowNamedState.State getState() {
      return state;
    }

    @Override
    public Map<String, Object> toMap() {
      Map<String, Object> map = new LinkedHashMap<>();
      map.put("clientWindow", clientWindow);
      map.put("state", state.toWireValue());
      return Collections.unmodifiableMap(map);
    }


    public enum State {

      FULLSCREEN("fullscreen"),
      MAXIMIZED("maximized"),
      MINIMIZED("minimized");

      private final String value;

      State(String value) {
        this.value = value;
      }

      public static State fromJson(String s) {
        for (State e : values()) {
          if (e.value.equals(s)) return e;
        }
        throw new BiDiException("Unknown State value: " + s);
      }

      public Object toWireValue() {
        return value;
      }

      @Override
      public String toString() {
        return String.valueOf(value);
      }
    }
  }

  public static class ClientWindowRectState implements SetClientWindowStateParameters {

    private final String clientWindow;
    private final String state;
    private Optional<Long> width;
    private Optional<Long> height;
    private Optional<Long> x;
    private Optional<Long> y;

    public ClientWindowRectState(String clientWindow, String state) {
      this.clientWindow = Objects.requireNonNull(clientWindow, "clientWindow is required");
      if (!Objects.equals(state, "normal")) {
        throw new BiDiException("state must be " + "normal" + ", got: " + state);
      }
      this.state = Objects.requireNonNull(state, "state is required");
      this.width = Optional.empty();
      this.height = Optional.empty();
      this.x = Optional.empty();
      this.y = Optional.empty();
    }

    ClientWindowRectState(String clientWindow, String state, Optional<Long> width, Optional<Long> height, Optional<Long> x, Optional<Long> y) {
      this.clientWindow = Objects.requireNonNull(clientWindow, "clientWindow is required");
      if (!Objects.equals(state, "normal")) {
        throw new BiDiException("state must be " + "normal" + ", got: " + state);
      }
      this.state = Objects.requireNonNull(state, "state is required");
      if (width != null && width.isPresent() && (width.get() < 0L || width.get() > 9007199254740991L)) {
        throw new BiDiException("width must be between 0 and 9007199254740991, got: " + width.get());
      }
      this.width = width != null ? width : Optional.empty();
      if (height != null && height.isPresent() && (height.get() < 0L || height.get() > 9007199254740991L)) {
        throw new BiDiException("height must be between 0 and 9007199254740991, got: " + height.get());
      }
      this.height = height != null ? height : Optional.empty();
      if (x != null && x.isPresent() && (x.get() < -9007199254740991L || x.get() > 9007199254740991L)) {
        throw new BiDiException("x must be between -9007199254740991 and 9007199254740991, got: " + x.get());
      }
      this.x = x != null ? x : Optional.empty();
      if (y != null && y.isPresent() && (y.get() < -9007199254740991L || y.get() > 9007199254740991L)) {
        throw new BiDiException("y must be between -9007199254740991 and 9007199254740991, got: " + y.get());
      }
      this.y = y != null ? y : Optional.empty();
    }

    public ClientWindowRectState setWidth(Long width) {
      if (width != null && (width < 0L || width > 9007199254740991L)) {
        throw new BiDiException("width must be between 0 and 9007199254740991, got: " + width);
      }
      this.width = Optional.ofNullable(width);
      return this;
    }

    public ClientWindowRectState setHeight(Long height) {
      if (height != null && (height < 0L || height > 9007199254740991L)) {
        throw new BiDiException("height must be between 0 and 9007199254740991, got: " + height);
      }
      this.height = Optional.ofNullable(height);
      return this;
    }

    public ClientWindowRectState setX(Long x) {
      if (x != null && (x < -9007199254740991L || x > 9007199254740991L)) {
        throw new BiDiException("x must be between -9007199254740991 and 9007199254740991, got: " + x);
      }
      this.x = Optional.ofNullable(x);
      return this;
    }

    public ClientWindowRectState setY(Long y) {
      if (y != null && (y < -9007199254740991L || y > 9007199254740991L)) {
        throw new BiDiException("y must be between -9007199254740991 and 9007199254740991, got: " + y);
      }
      this.y = Optional.ofNullable(y);
      return this;
    }

    public String getClientWindow() {
      return clientWindow;
    }

    public String getState() {
      return state;
    }

    public Optional<Long> getWidth() {
      return width;
    }

    public Optional<Long> getHeight() {
      return height;
    }

    public Optional<Long> getX() {
      return x;
    }

    public Optional<Long> getY() {
      return y;
    }

    @Override
    public Map<String, Object> toMap() {
      Map<String, Object> map = new LinkedHashMap<>();
      map.put("clientWindow", clientWindow);
      map.put("state", state);
      width.ifPresent(v -> map.put("width", v));
      height.ifPresent(v -> map.put("height", v));
      x.ifPresent(v -> map.put("x", v));
      y.ifPresent(v -> map.put("y", v));
      return Collections.unmodifiableMap(map);
    }

  }
}
