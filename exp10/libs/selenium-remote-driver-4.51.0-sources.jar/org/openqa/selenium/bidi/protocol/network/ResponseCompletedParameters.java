// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.network;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
@WarnOnUnknownFields
public class ResponseCompletedParameters {

  private final String context;
  private final boolean isBlocked;
  private final String navigation;
  private final long redirectCount;
  private final RequestData request;
  private final long timestamp;
  private final Optional<String> userContext;
  private final boolean userContextSet;
  private final Optional<java.util.List<String>> intercepts;
  private final ResponseData response;

  ResponseCompletedParameters(@Nullable String context, boolean isBlocked, @Nullable String navigation, long redirectCount, RequestData request, long timestamp, Optional<String> userContext, Optional<java.util.List<String>> intercepts, ResponseData response) {
    this.context = context;
    this.isBlocked = isBlocked;
    this.navigation = navigation;
    if (redirectCount < 0L || redirectCount > 9007199254740991L) {
      throw new BiDiException("redirectCount must be between 0 and 9007199254740991, got: " + redirectCount);
    }
    this.redirectCount = redirectCount;
    this.request = Objects.requireNonNull(request, "request is required");
    if (timestamp < 0L || timestamp > 9007199254740991L) {
      throw new BiDiException("timestamp must be between 0 and 9007199254740991, got: " + timestamp);
    }
    this.timestamp = timestamp;
    this.userContext = userContext != null ? userContext : Optional.empty();
    this.userContextSet = this.userContext.isPresent();
    Optional<java.util.List<String>> interceptsValue = intercepts != null ? intercepts : Optional.empty();
    this.intercepts = interceptsValue.map(v -> java.util.Collections.unmodifiableList(new java.util.ArrayList<>(v)));
    this.response = Objects.requireNonNull(response, "response is required");
  }

  public String getContext() {
    return context;
  }

  public boolean getIsBlocked() {
    return isBlocked;
  }

  public String getNavigation() {
    return navigation;
  }

  public long getRedirectCount() {
    return redirectCount;
  }

  public RequestData getRequest() {
    return request;
  }

  public long getTimestamp() {
    return timestamp;
  }

  public Optional<String> getUserContext() {
    return userContext;
  }

  public Optional<java.util.List<String>> getIntercepts() {
    return intercepts;
  }

  public ResponseData getResponse() {
    return response;
  }

}
