// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.bluetooth;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class SimulatePreconnectedPeripheralParameters {

  private final String context;
  private final String address;
  private final String name;
  private final java.util.List<BluetoothManufacturerData> manufacturerData;
  private final java.util.List<String> knownServiceUuids;

  public SimulatePreconnectedPeripheralParameters(String context, String address, String name, java.util.List<BluetoothManufacturerData> manufacturerData, java.util.List<String> knownServiceUuids) {
    this.context = Objects.requireNonNull(context, "context is required");
    this.address = Objects.requireNonNull(address, "address is required");
    this.name = Objects.requireNonNull(name, "name is required");
    this.manufacturerData = Objects.requireNonNull(manufacturerData, "manufacturerData is required");
    this.knownServiceUuids = Objects.requireNonNull(knownServiceUuids, "knownServiceUuids is required");
  }

  public String getContext() {
    return context;
  }

  public String getAddress() {
    return address;
  }

  public String getName() {
    return name;
  }

  public java.util.List<BluetoothManufacturerData> getManufacturerData() {
    return manufacturerData;
  }

  public java.util.List<String> getKnownServiceUuids() {
    return knownServiceUuids;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("context", context);
    map.put("address", address);
    map.put("name", name);
    map.put("manufacturerData", manufacturerData.stream().map(e -> java.util.Objects.requireNonNull(e, "manufacturerData element must not be null").toMap()).collect(java.util.stream.Collectors.toList()));
    map.put("knownServiceUuids", knownServiceUuids.stream().map(e -> java.util.Objects.requireNonNull(e, "knownServiceUuids element must not be null")).collect(java.util.stream.Collectors.toList()));
    return Collections.unmodifiableMap(map);
  }

}
