// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.network;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class ProvideResponseParameters {

  private final String request;
  private Optional<BytesValue> body;
  private Optional<java.util.List<SetCookieHeader>> cookies;
  private Optional<java.util.List<Header>> headers;
  private Optional<String> reasonPhrase;
  private Optional<Long> statusCode;

  public ProvideResponseParameters(String request) {
    this.request = Objects.requireNonNull(request, "request is required");
    this.body = Optional.empty();
    this.cookies = Optional.empty();
    this.headers = Optional.empty();
    this.reasonPhrase = Optional.empty();
    this.statusCode = Optional.empty();
  }

  ProvideResponseParameters(String request, Optional<BytesValue> body, Optional<java.util.List<SetCookieHeader>> cookies, Optional<java.util.List<Header>> headers, Optional<String> reasonPhrase, Optional<Long> statusCode) {
    this.request = Objects.requireNonNull(request, "request is required");
    this.body = body != null ? body : Optional.empty();
    this.cookies = cookies != null ? cookies : Optional.empty();
    this.headers = headers != null ? headers : Optional.empty();
    this.reasonPhrase = reasonPhrase != null ? reasonPhrase : Optional.empty();
    if (statusCode != null && statusCode.isPresent() && (statusCode.get() < 0L || statusCode.get() > 9007199254740991L)) {
      throw new BiDiException("statusCode must be between 0 and 9007199254740991, got: " + statusCode.get());
    }
    this.statusCode = statusCode != null ? statusCode : Optional.empty();
  }

  public ProvideResponseParameters setBody(BytesValue body) {
    this.body = Optional.ofNullable(body);
    return this;
  }

  public ProvideResponseParameters setCookies(java.util.List<SetCookieHeader> cookies) {
    this.cookies = Optional.ofNullable(cookies);
    return this;
  }

  public ProvideResponseParameters setHeaders(java.util.List<Header> headers) {
    this.headers = Optional.ofNullable(headers);
    return this;
  }

  public ProvideResponseParameters setReasonPhrase(String reasonPhrase) {
    this.reasonPhrase = Optional.ofNullable(reasonPhrase);
    return this;
  }

  public ProvideResponseParameters setStatusCode(Long statusCode) {
    if (statusCode != null && (statusCode < 0L || statusCode > 9007199254740991L)) {
      throw new BiDiException("statusCode must be between 0 and 9007199254740991, got: " + statusCode);
    }
    this.statusCode = Optional.ofNullable(statusCode);
    return this;
  }

  public String getRequest() {
    return request;
  }

  public Optional<BytesValue> getBody() {
    return body;
  }

  public Optional<java.util.List<SetCookieHeader>> getCookies() {
    return cookies;
  }

  public Optional<java.util.List<Header>> getHeaders() {
    return headers;
  }

  public Optional<String> getReasonPhrase() {
    return reasonPhrase;
  }

  public Optional<Long> getStatusCode() {
    return statusCode;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("request", request);
    body.ifPresent(v -> map.put("body", v.toMap()));
    cookies.ifPresent(v -> map.put("cookies", v.stream().map(e -> java.util.Objects.requireNonNull(e, "cookies element must not be null").toMap()).collect(java.util.stream.Collectors.toList())));
    headers.ifPresent(v -> map.put("headers", v.stream().map(e -> java.util.Objects.requireNonNull(e, "headers element must not be null").toMap()).collect(java.util.stream.Collectors.toList())));
    reasonPhrase.ifPresent(v -> map.put("reasonPhrase", v));
    statusCode.ifPresent(v -> map.put("statusCode", v));
    return Collections.unmodifiableMap(map);
  }

}
