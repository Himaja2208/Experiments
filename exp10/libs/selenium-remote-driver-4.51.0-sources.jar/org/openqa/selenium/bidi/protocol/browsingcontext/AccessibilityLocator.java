// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.browsingcontext;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class AccessibilityLocator implements Locator {

  private final String type;
  private final AccessibilityLocator.Value value;

  public AccessibilityLocator(String type, AccessibilityLocator.Value value) {
    if (!Objects.equals(type, "accessibility")) {
      throw new BiDiException("type must be " + "accessibility" + ", got: " + type);
    }
    this.type = Objects.requireNonNull(type, "type is required");
    this.value = Objects.requireNonNull(value, "value is required");
  }

  public String getType() {
    return type;
  }

  public AccessibilityLocator.Value getValue() {
    return value;
  }

  @Override
  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("type", type);
    map.put("value", value.toMap());
    return Collections.unmodifiableMap(map);
  }


  public static class Value {

    private Optional<String> name;
    private Optional<String> role;

    public Value() {
      this.name = Optional.empty();
      this.role = Optional.empty();
    }

    Value(Optional<String> name, Optional<String> role) {
      this.name = name != null ? name : Optional.empty();
      this.role = role != null ? role : Optional.empty();
    }

    public Value setName(String name) {
      this.name = Optional.ofNullable(name);
      return this;
    }

    public Value setRole(String role) {
      this.role = Optional.ofNullable(role);
      return this;
    }

    public Optional<String> getName() {
      return name;
    }

    public Optional<String> getRole() {
      return role;
    }

    public Map<String, Object> toMap() {
      Map<String, Object> map = new LinkedHashMap<>();
      name.ifPresent(v -> map.put("name", v));
      role.ifPresent(v -> map.put("role", v));
      return Collections.unmodifiableMap(map);
    }

  }
}
