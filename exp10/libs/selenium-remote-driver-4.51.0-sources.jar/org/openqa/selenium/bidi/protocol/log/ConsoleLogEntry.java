// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.log;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
@WarnOnUnknownFields
public class ConsoleLogEntry implements Entry {

  private final Level level;
  private final org.openqa.selenium.bidi.protocol.script.Source source;
  private final String text;
  private final long timestamp;
  private final Optional<org.openqa.selenium.bidi.protocol.script.StackTrace> stackTrace;
  private final String type;
  private final String method;
  private final java.util.List<org.openqa.selenium.bidi.protocol.script.RemoteValue> args;

  ConsoleLogEntry(Level level, org.openqa.selenium.bidi.protocol.script.Source source, @Nullable String text, long timestamp, Optional<org.openqa.selenium.bidi.protocol.script.StackTrace> stackTrace, String type, String method, java.util.List<org.openqa.selenium.bidi.protocol.script.RemoteValue> args) {
    this.level = Objects.requireNonNull(level, "level is required");
    this.source = Objects.requireNonNull(source, "source is required");
    this.text = text;
    if (timestamp < 0L || timestamp > 9007199254740991L) {
      throw new BiDiException("timestamp must be between 0 and 9007199254740991, got: " + timestamp);
    }
    this.timestamp = timestamp;
    this.stackTrace = stackTrace != null ? stackTrace : Optional.empty();
    if (!Objects.equals(type, "console")) {
      throw new BiDiException("type must be " + "console" + ", got: " + type);
    }
    this.type = Objects.requireNonNull(type, "type is required");
    this.method = Objects.requireNonNull(method, "method is required");
    this.args = java.util.Collections.unmodifiableList(new java.util.ArrayList<>(Objects.requireNonNull(args, "args is required")));
  }

  public Level getLevel() {
    return level;
  }

  public org.openqa.selenium.bidi.protocol.script.Source getSource() {
    return source;
  }

  public String getText() {
    return text;
  }

  public long getTimestamp() {
    return timestamp;
  }

  public Optional<org.openqa.selenium.bidi.protocol.script.StackTrace> getStackTrace() {
    return stackTrace;
  }

  public String getType() {
    return type;
  }

  public String getMethod() {
    return method;
  }

  public java.util.List<org.openqa.selenium.bidi.protocol.script.RemoteValue> getArgs() {
    return args;
  }

}
