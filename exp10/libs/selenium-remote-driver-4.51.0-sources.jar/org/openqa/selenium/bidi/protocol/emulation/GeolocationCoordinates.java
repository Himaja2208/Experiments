// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.emulation;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class GeolocationCoordinates {

  private final Number latitude;
  private final Number longitude;
  private Optional<Number> accuracy;
  private Optional<Number> altitude;
  private boolean altitudeSet;
  private Optional<Number> altitudeAccuracy;
  private boolean altitudeAccuracySet;
  private Optional<Number> heading;
  private boolean headingSet;
  private Optional<Number> speed;
  private boolean speedSet;

  public GeolocationCoordinates(Number latitude, Number longitude) {
    this.latitude = Objects.requireNonNull(latitude, "latitude is required");
    this.longitude = Objects.requireNonNull(longitude, "longitude is required");
    this.accuracy = Optional.empty();
    this.altitude = Optional.empty();
    this.altitudeAccuracy = Optional.empty();
    this.heading = Optional.empty();
    this.speed = Optional.empty();
  }

  GeolocationCoordinates(Number latitude, Number longitude, Optional<Number> accuracy, Optional<Number> altitude, Optional<Number> altitudeAccuracy, Optional<Number> heading, Optional<Number> speed) {
    this.latitude = Objects.requireNonNull(latitude, "latitude is required");
    this.longitude = Objects.requireNonNull(longitude, "longitude is required");
    this.accuracy = accuracy != null ? accuracy : Optional.empty();
    this.altitude = altitude != null ? altitude : Optional.empty();
    this.altitudeSet = this.altitude.isPresent();
    this.altitudeAccuracy = altitudeAccuracy != null ? altitudeAccuracy : Optional.empty();
    this.altitudeAccuracySet = this.altitudeAccuracy.isPresent();
    this.heading = heading != null ? heading : Optional.empty();
    this.headingSet = this.heading.isPresent();
    this.speed = speed != null ? speed : Optional.empty();
    this.speedSet = this.speed.isPresent();
  }

  public GeolocationCoordinates setAccuracy(Number accuracy) {
    this.accuracy = Optional.ofNullable(accuracy);
    return this;
  }

  public GeolocationCoordinates setAltitude(Number altitude) {
    this.altitude = Optional.ofNullable(altitude);
    this.altitudeSet = true;
    return this;
  }

  public GeolocationCoordinates setAltitudeAccuracy(Number altitudeAccuracy) {
    this.altitudeAccuracy = Optional.ofNullable(altitudeAccuracy);
    this.altitudeAccuracySet = true;
    return this;
  }

  public GeolocationCoordinates setHeading(Number heading) {
    this.heading = Optional.ofNullable(heading);
    this.headingSet = true;
    return this;
  }

  public GeolocationCoordinates setSpeed(Number speed) {
    this.speed = Optional.ofNullable(speed);
    this.speedSet = true;
    return this;
  }

  public Number getLatitude() {
    return latitude;
  }

  public Number getLongitude() {
    return longitude;
  }

  public Optional<Number> getAccuracy() {
    return accuracy;
  }

  public Optional<Number> getAltitude() {
    return altitude;
  }

  public Optional<Number> getAltitudeAccuracy() {
    return altitudeAccuracy;
  }

  public Optional<Number> getHeading() {
    return heading;
  }

  public Optional<Number> getSpeed() {
    return speed;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("latitude", latitude);
    map.put("longitude", longitude);
    accuracy.ifPresent(v -> map.put("accuracy", v));
    if (altitudeSet) {
      map.put("altitude", altitude.isPresent() ? altitude.get() : null);
    }
    if (altitudeAccuracySet) {
      map.put("altitudeAccuracy", altitudeAccuracy.isPresent() ? altitudeAccuracy.get() : null);
    }
    if (headingSet) {
      map.put("heading", heading.isPresent() ? heading.get() : null);
    }
    if (speedSet) {
      map.put("speed", speed.isPresent() ? speed.get() : null);
    }
    return Collections.unmodifiableMap(map);
  }

}
