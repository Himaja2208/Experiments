// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.module;

import org.jetbrains.annotations.ApiStatus;
import org.openqa.selenium.Beta;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.bidi.Command;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.bidi.Event;
import org.openqa.selenium.bidi.Module;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
@SuppressWarnings("unchecked")
public class Emulation extends Module {

  public Emulation(WebDriver driver) {
    super(driver);
  }

  public void setForcedColorsModeThemeOverride(org.openqa.selenium.bidi.protocol.emulation.SetForcedColorsModeThemeOverrideParameters params) {
    send(new Command<>("emulation.setForcedColorsModeThemeOverride", params.toMap()));
  }

  public void setGeolocationOverride(org.openqa.selenium.bidi.protocol.emulation.SetGeolocationOverrideParameters params) {
    send(new Command<>("emulation.setGeolocationOverride", params.toMap()));
  }

  public void setLocaleOverride(org.openqa.selenium.bidi.protocol.emulation.SetLocaleOverrideParameters params) {
    send(new Command<>("emulation.setLocaleOverride", params.toMap()));
  }

  public void setMediaFeaturesOverride(org.openqa.selenium.bidi.protocol.emulation.SetMediaFeaturesOverrideParameters params) {
    send(new Command<>("emulation.setMediaFeaturesOverride", params.toMap()));
  }

  public void setNetworkConditions(org.openqa.selenium.bidi.protocol.emulation.SetNetworkConditionsParameters params) {
    send(new Command<>("emulation.setNetworkConditions", params.toMap()));
  }

  public void setScreenOrientationOverride(org.openqa.selenium.bidi.protocol.emulation.SetScreenOrientationOverrideParameters params) {
    send(new Command<>("emulation.setScreenOrientationOverride", params.toMap()));
  }

  public void setScreenSettingsOverride(org.openqa.selenium.bidi.protocol.emulation.SetScreenSettingsOverrideParameters params) {
    send(new Command<>("emulation.setScreenSettingsOverride", params.toMap()));
  }

  public void setScriptingEnabled(org.openqa.selenium.bidi.protocol.emulation.SetScriptingEnabledParameters params) {
    send(new Command<>("emulation.setScriptingEnabled", params.toMap()));
  }

  public void setScrollbarTypeOverride(org.openqa.selenium.bidi.protocol.emulation.SetScrollbarTypeOverrideParameters params) {
    send(new Command<>("emulation.setScrollbarTypeOverride", params.toMap()));
  }

  public void setTextLayoutModeOverride(org.openqa.selenium.bidi.protocol.emulation.SetTextLayoutModeOverrideParameters params) {
    send(new Command<>("emulation.setTextLayoutModeOverride", params.toMap()));
  }

  public void setTimezoneOverride(org.openqa.selenium.bidi.protocol.emulation.SetTimezoneOverrideParameters params) {
    send(new Command<>("emulation.setTimezoneOverride", params.toMap()));
  }

  public void setTouchOverride(org.openqa.selenium.bidi.protocol.emulation.SetTouchOverrideParameters params) {
    send(new Command<>("emulation.setTouchOverride", params.toMap()));
  }

  public void setUserAgentOverride(org.openqa.selenium.bidi.protocol.emulation.SetUserAgentOverrideParameters params) {
    send(new Command<>("emulation.setUserAgentOverride", params.toMap()));
  }

  public void setViewportMetaOverride(org.openqa.selenium.bidi.protocol.emulation.SetViewportMetaOverrideParameters params) {
    send(new Command<>("emulation.setViewportMetaOverride", params.toMap()));
  }

}
