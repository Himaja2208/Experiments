// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.emulation;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class MediaFeatures {

  private Optional<MediaFeatures.AnyHover> anyHover;
  private boolean anyHoverSet;
  private Optional<MediaFeatures.AnyPointer> anyPointer;
  private boolean anyPointerSet;
  private Optional<Long> color;
  private boolean colorSet;
  private Optional<MediaFeatures.ColorGamut> colorGamut;
  private boolean colorGamutSet;
  private Optional<Long> colorIndex;
  private boolean colorIndexSet;
  private Optional<MediaFeatures.DisplayMode> displayMode;
  private boolean displayModeSet;
  private Optional<MediaFeatures.DynamicRange> dynamicRange;
  private boolean dynamicRangeSet;
  private Optional<MediaFeatures.EnvironmentBlending> environmentBlending;
  private boolean environmentBlendingSet;
  private Optional<MediaFeatures.ForcedColors> forcedColors;
  private boolean forcedColorsSet;
  private Optional<MediaFeatures.Grid> grid;
  private boolean gridSet;
  private Optional<Long> horizontalViewportSegments;
  private boolean horizontalViewportSegmentsSet;
  private Optional<MediaFeatures.Hover> hover;
  private boolean hoverSet;
  private Optional<MediaFeatures.InvertedColors> invertedColors;
  private boolean invertedColorsSet;
  private Optional<Long> monochrome;
  private boolean monochromeSet;
  private Optional<MediaFeatures.NavControls> navControls;
  private boolean navControlsSet;
  private Optional<MediaFeatures.OverflowBlock> overflowBlock;
  private boolean overflowBlockSet;
  private Optional<MediaFeatures.OverflowInline> overflowInline;
  private boolean overflowInlineSet;
  private Optional<MediaFeatures.Pointer> pointer;
  private boolean pointerSet;
  private Optional<MediaFeatures.PrefersColorScheme> prefersColorScheme;
  private boolean prefersColorSchemeSet;
  private Optional<MediaFeatures.PrefersContrast> prefersContrast;
  private boolean prefersContrastSet;
  private Optional<MediaFeatures.PrefersReducedData> prefersReducedData;
  private boolean prefersReducedDataSet;
  private Optional<MediaFeatures.PrefersReducedMotion> prefersReducedMotion;
  private boolean prefersReducedMotionSet;
  private Optional<MediaFeatures.PrefersReducedTransparency> prefersReducedTransparency;
  private boolean prefersReducedTransparencySet;
  private Optional<MediaFeatures.Scan> scan;
  private boolean scanSet;
  private Optional<MediaFeatures.Scripting> scripting;
  private boolean scriptingSet;
  private Optional<MediaFeatures.Update> update;
  private boolean updateSet;
  private Optional<Long> verticalViewportSegments;
  private boolean verticalViewportSegmentsSet;
  private Optional<MediaFeatures.VideoColorGamut> videoColorGamut;
  private boolean videoColorGamutSet;
  private Optional<MediaFeatures.VideoDynamicRange> videoDynamicRange;
  private boolean videoDynamicRangeSet;

  public MediaFeatures() {
    this.anyHover = Optional.empty();
    this.anyPointer = Optional.empty();
    this.color = Optional.empty();
    this.colorGamut = Optional.empty();
    this.colorIndex = Optional.empty();
    this.displayMode = Optional.empty();
    this.dynamicRange = Optional.empty();
    this.environmentBlending = Optional.empty();
    this.forcedColors = Optional.empty();
    this.grid = Optional.empty();
    this.horizontalViewportSegments = Optional.empty();
    this.hover = Optional.empty();
    this.invertedColors = Optional.empty();
    this.monochrome = Optional.empty();
    this.navControls = Optional.empty();
    this.overflowBlock = Optional.empty();
    this.overflowInline = Optional.empty();
    this.pointer = Optional.empty();
    this.prefersColorScheme = Optional.empty();
    this.prefersContrast = Optional.empty();
    this.prefersReducedData = Optional.empty();
    this.prefersReducedMotion = Optional.empty();
    this.prefersReducedTransparency = Optional.empty();
    this.scan = Optional.empty();
    this.scripting = Optional.empty();
    this.update = Optional.empty();
    this.verticalViewportSegments = Optional.empty();
    this.videoColorGamut = Optional.empty();
    this.videoDynamicRange = Optional.empty();
  }

  MediaFeatures(Optional<MediaFeatures.AnyHover> anyHover, Optional<MediaFeatures.AnyPointer> anyPointer, Optional<Long> color, Optional<MediaFeatures.ColorGamut> colorGamut, Optional<Long> colorIndex, Optional<MediaFeatures.DisplayMode> displayMode, Optional<MediaFeatures.DynamicRange> dynamicRange, Optional<MediaFeatures.EnvironmentBlending> environmentBlending, Optional<MediaFeatures.ForcedColors> forcedColors, Optional<MediaFeatures.Grid> grid, Optional<Long> horizontalViewportSegments, Optional<MediaFeatures.Hover> hover, Optional<MediaFeatures.InvertedColors> invertedColors, Optional<Long> monochrome, Optional<MediaFeatures.NavControls> navControls, Optional<MediaFeatures.OverflowBlock> overflowBlock, Optional<MediaFeatures.OverflowInline> overflowInline, Optional<MediaFeatures.Pointer> pointer, Optional<MediaFeatures.PrefersColorScheme> prefersColorScheme, Optional<MediaFeatures.PrefersContrast> prefersContrast, Optional<MediaFeatures.PrefersReducedData> prefersReducedData, Optional<MediaFeatures.PrefersReducedMotion> prefersReducedMotion, Optional<MediaFeatures.PrefersReducedTransparency> prefersReducedTransparency, Optional<MediaFeatures.Scan> scan, Optional<MediaFeatures.Scripting> scripting, Optional<MediaFeatures.Update> update, Optional<Long> verticalViewportSegments, Optional<MediaFeatures.VideoColorGamut> videoColorGamut, Optional<MediaFeatures.VideoDynamicRange> videoDynamicRange) {
    this.anyHover = anyHover != null ? anyHover : Optional.empty();
    this.anyHoverSet = this.anyHover.isPresent();
    this.anyPointer = anyPointer != null ? anyPointer : Optional.empty();
    this.anyPointerSet = this.anyPointer.isPresent();
    if (color != null && color.isPresent() && (color.get() < 0L || color.get() > 9007199254740991L)) {
      throw new BiDiException("color must be between 0 and 9007199254740991, got: " + color.get());
    }
    this.color = color != null ? color : Optional.empty();
    this.colorSet = this.color.isPresent();
    this.colorGamut = colorGamut != null ? colorGamut : Optional.empty();
    this.colorGamutSet = this.colorGamut.isPresent();
    if (colorIndex != null && colorIndex.isPresent() && (colorIndex.get() < 0L || colorIndex.get() > 9007199254740991L)) {
      throw new BiDiException("color-index must be between 0 and 9007199254740991, got: " + colorIndex.get());
    }
    this.colorIndex = colorIndex != null ? colorIndex : Optional.empty();
    this.colorIndexSet = this.colorIndex.isPresent();
    this.displayMode = displayMode != null ? displayMode : Optional.empty();
    this.displayModeSet = this.displayMode.isPresent();
    this.dynamicRange = dynamicRange != null ? dynamicRange : Optional.empty();
    this.dynamicRangeSet = this.dynamicRange.isPresent();
    this.environmentBlending = environmentBlending != null ? environmentBlending : Optional.empty();
    this.environmentBlendingSet = this.environmentBlending.isPresent();
    this.forcedColors = forcedColors != null ? forcedColors : Optional.empty();
    this.forcedColorsSet = this.forcedColors.isPresent();
    this.grid = grid != null ? grid : Optional.empty();
    this.gridSet = this.grid.isPresent();
    if (horizontalViewportSegments != null && horizontalViewportSegments.isPresent() && (horizontalViewportSegments.get() < 0L || horizontalViewportSegments.get() > 9007199254740991L)) {
      throw new BiDiException("horizontal-viewport-segments must be between 0 and 9007199254740991, got: " + horizontalViewportSegments.get());
    }
    this.horizontalViewportSegments = horizontalViewportSegments != null ? horizontalViewportSegments : Optional.empty();
    this.horizontalViewportSegmentsSet = this.horizontalViewportSegments.isPresent();
    this.hover = hover != null ? hover : Optional.empty();
    this.hoverSet = this.hover.isPresent();
    this.invertedColors = invertedColors != null ? invertedColors : Optional.empty();
    this.invertedColorsSet = this.invertedColors.isPresent();
    if (monochrome != null && monochrome.isPresent() && (monochrome.get() < 0L || monochrome.get() > 9007199254740991L)) {
      throw new BiDiException("monochrome must be between 0 and 9007199254740991, got: " + monochrome.get());
    }
    this.monochrome = monochrome != null ? monochrome : Optional.empty();
    this.monochromeSet = this.monochrome.isPresent();
    this.navControls = navControls != null ? navControls : Optional.empty();
    this.navControlsSet = this.navControls.isPresent();
    this.overflowBlock = overflowBlock != null ? overflowBlock : Optional.empty();
    this.overflowBlockSet = this.overflowBlock.isPresent();
    this.overflowInline = overflowInline != null ? overflowInline : Optional.empty();
    this.overflowInlineSet = this.overflowInline.isPresent();
    this.pointer = pointer != null ? pointer : Optional.empty();
    this.pointerSet = this.pointer.isPresent();
    this.prefersColorScheme = prefersColorScheme != null ? prefersColorScheme : Optional.empty();
    this.prefersColorSchemeSet = this.prefersColorScheme.isPresent();
    this.prefersContrast = prefersContrast != null ? prefersContrast : Optional.empty();
    this.prefersContrastSet = this.prefersContrast.isPresent();
    this.prefersReducedData = prefersReducedData != null ? prefersReducedData : Optional.empty();
    this.prefersReducedDataSet = this.prefersReducedData.isPresent();
    this.prefersReducedMotion = prefersReducedMotion != null ? prefersReducedMotion : Optional.empty();
    this.prefersReducedMotionSet = this.prefersReducedMotion.isPresent();
    this.prefersReducedTransparency = prefersReducedTransparency != null ? prefersReducedTransparency : Optional.empty();
    this.prefersReducedTransparencySet = this.prefersReducedTransparency.isPresent();
    this.scan = scan != null ? scan : Optional.empty();
    this.scanSet = this.scan.isPresent();
    this.scripting = scripting != null ? scripting : Optional.empty();
    this.scriptingSet = this.scripting.isPresent();
    this.update = update != null ? update : Optional.empty();
    this.updateSet = this.update.isPresent();
    if (verticalViewportSegments != null && verticalViewportSegments.isPresent() && (verticalViewportSegments.get() < 0L || verticalViewportSegments.get() > 9007199254740991L)) {
      throw new BiDiException("vertical-viewport-segments must be between 0 and 9007199254740991, got: " + verticalViewportSegments.get());
    }
    this.verticalViewportSegments = verticalViewportSegments != null ? verticalViewportSegments : Optional.empty();
    this.verticalViewportSegmentsSet = this.verticalViewportSegments.isPresent();
    this.videoColorGamut = videoColorGamut != null ? videoColorGamut : Optional.empty();
    this.videoColorGamutSet = this.videoColorGamut.isPresent();
    this.videoDynamicRange = videoDynamicRange != null ? videoDynamicRange : Optional.empty();
    this.videoDynamicRangeSet = this.videoDynamicRange.isPresent();
  }

  public MediaFeatures setAnyHover(MediaFeatures.AnyHover anyHover) {
    this.anyHover = Optional.ofNullable(anyHover);
    this.anyHoverSet = true;
    return this;
  }

  public MediaFeatures setAnyPointer(MediaFeatures.AnyPointer anyPointer) {
    this.anyPointer = Optional.ofNullable(anyPointer);
    this.anyPointerSet = true;
    return this;
  }

  public MediaFeatures setColor(Long color) {
    if (color != null && (color < 0L || color > 9007199254740991L)) {
      throw new BiDiException("color must be between 0 and 9007199254740991, got: " + color);
    }
    this.color = Optional.ofNullable(color);
    this.colorSet = true;
    return this;
  }

  public MediaFeatures setColorGamut(MediaFeatures.ColorGamut colorGamut) {
    this.colorGamut = Optional.ofNullable(colorGamut);
    this.colorGamutSet = true;
    return this;
  }

  public MediaFeatures setColorIndex(Long colorIndex) {
    if (colorIndex != null && (colorIndex < 0L || colorIndex > 9007199254740991L)) {
      throw new BiDiException("color-index must be between 0 and 9007199254740991, got: " + colorIndex);
    }
    this.colorIndex = Optional.ofNullable(colorIndex);
    this.colorIndexSet = true;
    return this;
  }

  public MediaFeatures setDisplayMode(MediaFeatures.DisplayMode displayMode) {
    this.displayMode = Optional.ofNullable(displayMode);
    this.displayModeSet = true;
    return this;
  }

  public MediaFeatures setDynamicRange(MediaFeatures.DynamicRange dynamicRange) {
    this.dynamicRange = Optional.ofNullable(dynamicRange);
    this.dynamicRangeSet = true;
    return this;
  }

  public MediaFeatures setEnvironmentBlending(MediaFeatures.EnvironmentBlending environmentBlending) {
    this.environmentBlending = Optional.ofNullable(environmentBlending);
    this.environmentBlendingSet = true;
    return this;
  }

  public MediaFeatures setForcedColors(MediaFeatures.ForcedColors forcedColors) {
    this.forcedColors = Optional.ofNullable(forcedColors);
    this.forcedColorsSet = true;
    return this;
  }

  public MediaFeatures setGrid(MediaFeatures.Grid grid) {
    this.grid = Optional.ofNullable(grid);
    this.gridSet = true;
    return this;
  }

  public MediaFeatures setHorizontalViewportSegments(Long horizontalViewportSegments) {
    if (horizontalViewportSegments != null && (horizontalViewportSegments < 0L || horizontalViewportSegments > 9007199254740991L)) {
      throw new BiDiException("horizontal-viewport-segments must be between 0 and 9007199254740991, got: " + horizontalViewportSegments);
    }
    this.horizontalViewportSegments = Optional.ofNullable(horizontalViewportSegments);
    this.horizontalViewportSegmentsSet = true;
    return this;
  }

  public MediaFeatures setHover(MediaFeatures.Hover hover) {
    this.hover = Optional.ofNullable(hover);
    this.hoverSet = true;
    return this;
  }

  public MediaFeatures setInvertedColors(MediaFeatures.InvertedColors invertedColors) {
    this.invertedColors = Optional.ofNullable(invertedColors);
    this.invertedColorsSet = true;
    return this;
  }

  public MediaFeatures setMonochrome(Long monochrome) {
    if (monochrome != null && (monochrome < 0L || monochrome > 9007199254740991L)) {
      throw new BiDiException("monochrome must be between 0 and 9007199254740991, got: " + monochrome);
    }
    this.monochrome = Optional.ofNullable(monochrome);
    this.monochromeSet = true;
    return this;
  }

  public MediaFeatures setNavControls(MediaFeatures.NavControls navControls) {
    this.navControls = Optional.ofNullable(navControls);
    this.navControlsSet = true;
    return this;
  }

  public MediaFeatures setOverflowBlock(MediaFeatures.OverflowBlock overflowBlock) {
    this.overflowBlock = Optional.ofNullable(overflowBlock);
    this.overflowBlockSet = true;
    return this;
  }

  public MediaFeatures setOverflowInline(MediaFeatures.OverflowInline overflowInline) {
    this.overflowInline = Optional.ofNullable(overflowInline);
    this.overflowInlineSet = true;
    return this;
  }

  public MediaFeatures setPointer(MediaFeatures.Pointer pointer) {
    this.pointer = Optional.ofNullable(pointer);
    this.pointerSet = true;
    return this;
  }

  public MediaFeatures setPrefersColorScheme(MediaFeatures.PrefersColorScheme prefersColorScheme) {
    this.prefersColorScheme = Optional.ofNullable(prefersColorScheme);
    this.prefersColorSchemeSet = true;
    return this;
  }

  public MediaFeatures setPrefersContrast(MediaFeatures.PrefersContrast prefersContrast) {
    this.prefersContrast = Optional.ofNullable(prefersContrast);
    this.prefersContrastSet = true;
    return this;
  }

  public MediaFeatures setPrefersReducedData(MediaFeatures.PrefersReducedData prefersReducedData) {
    this.prefersReducedData = Optional.ofNullable(prefersReducedData);
    this.prefersReducedDataSet = true;
    return this;
  }

  public MediaFeatures setPrefersReducedMotion(MediaFeatures.PrefersReducedMotion prefersReducedMotion) {
    this.prefersReducedMotion = Optional.ofNullable(prefersReducedMotion);
    this.prefersReducedMotionSet = true;
    return this;
  }

  public MediaFeatures setPrefersReducedTransparency(MediaFeatures.PrefersReducedTransparency prefersReducedTransparency) {
    this.prefersReducedTransparency = Optional.ofNullable(prefersReducedTransparency);
    this.prefersReducedTransparencySet = true;
    return this;
  }

  public MediaFeatures setScan(MediaFeatures.Scan scan) {
    this.scan = Optional.ofNullable(scan);
    this.scanSet = true;
    return this;
  }

  public MediaFeatures setScripting(MediaFeatures.Scripting scripting) {
    this.scripting = Optional.ofNullable(scripting);
    this.scriptingSet = true;
    return this;
  }

  public MediaFeatures setUpdate(MediaFeatures.Update update) {
    this.update = Optional.ofNullable(update);
    this.updateSet = true;
    return this;
  }

  public MediaFeatures setVerticalViewportSegments(Long verticalViewportSegments) {
    if (verticalViewportSegments != null && (verticalViewportSegments < 0L || verticalViewportSegments > 9007199254740991L)) {
      throw new BiDiException("vertical-viewport-segments must be between 0 and 9007199254740991, got: " + verticalViewportSegments);
    }
    this.verticalViewportSegments = Optional.ofNullable(verticalViewportSegments);
    this.verticalViewportSegmentsSet = true;
    return this;
  }

  public MediaFeatures setVideoColorGamut(MediaFeatures.VideoColorGamut videoColorGamut) {
    this.videoColorGamut = Optional.ofNullable(videoColorGamut);
    this.videoColorGamutSet = true;
    return this;
  }

  public MediaFeatures setVideoDynamicRange(MediaFeatures.VideoDynamicRange videoDynamicRange) {
    this.videoDynamicRange = Optional.ofNullable(videoDynamicRange);
    this.videoDynamicRangeSet = true;
    return this;
  }

  public Optional<MediaFeatures.AnyHover> getAnyHover() {
    return anyHover;
  }

  public Optional<MediaFeatures.AnyPointer> getAnyPointer() {
    return anyPointer;
  }

  public Optional<Long> getColor() {
    return color;
  }

  public Optional<MediaFeatures.ColorGamut> getColorGamut() {
    return colorGamut;
  }

  public Optional<Long> getColorIndex() {
    return colorIndex;
  }

  public Optional<MediaFeatures.DisplayMode> getDisplayMode() {
    return displayMode;
  }

  public Optional<MediaFeatures.DynamicRange> getDynamicRange() {
    return dynamicRange;
  }

  public Optional<MediaFeatures.EnvironmentBlending> getEnvironmentBlending() {
    return environmentBlending;
  }

  public Optional<MediaFeatures.ForcedColors> getForcedColors() {
    return forcedColors;
  }

  public Optional<MediaFeatures.Grid> getGrid() {
    return grid;
  }

  public Optional<Long> getHorizontalViewportSegments() {
    return horizontalViewportSegments;
  }

  public Optional<MediaFeatures.Hover> getHover() {
    return hover;
  }

  public Optional<MediaFeatures.InvertedColors> getInvertedColors() {
    return invertedColors;
  }

  public Optional<Long> getMonochrome() {
    return monochrome;
  }

  public Optional<MediaFeatures.NavControls> getNavControls() {
    return navControls;
  }

  public Optional<MediaFeatures.OverflowBlock> getOverflowBlock() {
    return overflowBlock;
  }

  public Optional<MediaFeatures.OverflowInline> getOverflowInline() {
    return overflowInline;
  }

  public Optional<MediaFeatures.Pointer> getPointer() {
    return pointer;
  }

  public Optional<MediaFeatures.PrefersColorScheme> getPrefersColorScheme() {
    return prefersColorScheme;
  }

  public Optional<MediaFeatures.PrefersContrast> getPrefersContrast() {
    return prefersContrast;
  }

  public Optional<MediaFeatures.PrefersReducedData> getPrefersReducedData() {
    return prefersReducedData;
  }

  public Optional<MediaFeatures.PrefersReducedMotion> getPrefersReducedMotion() {
    return prefersReducedMotion;
  }

  public Optional<MediaFeatures.PrefersReducedTransparency> getPrefersReducedTransparency() {
    return prefersReducedTransparency;
  }

  public Optional<MediaFeatures.Scan> getScan() {
    return scan;
  }

  public Optional<MediaFeatures.Scripting> getScripting() {
    return scripting;
  }

  public Optional<MediaFeatures.Update> getUpdate() {
    return update;
  }

  public Optional<Long> getVerticalViewportSegments() {
    return verticalViewportSegments;
  }

  public Optional<MediaFeatures.VideoColorGamut> getVideoColorGamut() {
    return videoColorGamut;
  }

  public Optional<MediaFeatures.VideoDynamicRange> getVideoDynamicRange() {
    return videoDynamicRange;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    if (anyHoverSet) {
      map.put("any-hover", anyHover.isPresent() ? anyHover.get().toWireValue() : null);
    }
    if (anyPointerSet) {
      map.put("any-pointer", anyPointer.isPresent() ? anyPointer.get().toWireValue() : null);
    }
    if (colorSet) {
      map.put("color", color.isPresent() ? color.get() : null);
    }
    if (colorGamutSet) {
      map.put("color-gamut", colorGamut.isPresent() ? colorGamut.get().toWireValue() : null);
    }
    if (colorIndexSet) {
      map.put("color-index", colorIndex.isPresent() ? colorIndex.get() : null);
    }
    if (displayModeSet) {
      map.put("display-mode", displayMode.isPresent() ? displayMode.get().toWireValue() : null);
    }
    if (dynamicRangeSet) {
      map.put("dynamic-range", dynamicRange.isPresent() ? dynamicRange.get().toWireValue() : null);
    }
    if (environmentBlendingSet) {
      map.put("environment-blending", environmentBlending.isPresent() ? environmentBlending.get().toWireValue() : null);
    }
    if (forcedColorsSet) {
      map.put("forced-colors", forcedColors.isPresent() ? forcedColors.get().toWireValue() : null);
    }
    if (gridSet) {
      map.put("grid", grid.isPresent() ? grid.get().toWireValue() : null);
    }
    if (horizontalViewportSegmentsSet) {
      map.put("horizontal-viewport-segments", horizontalViewportSegments.isPresent() ? horizontalViewportSegments.get() : null);
    }
    if (hoverSet) {
      map.put("hover", hover.isPresent() ? hover.get().toWireValue() : null);
    }
    if (invertedColorsSet) {
      map.put("inverted-colors", invertedColors.isPresent() ? invertedColors.get().toWireValue() : null);
    }
    if (monochromeSet) {
      map.put("monochrome", monochrome.isPresent() ? monochrome.get() : null);
    }
    if (navControlsSet) {
      map.put("nav-controls", navControls.isPresent() ? navControls.get().toWireValue() : null);
    }
    if (overflowBlockSet) {
      map.put("overflow-block", overflowBlock.isPresent() ? overflowBlock.get().toWireValue() : null);
    }
    if (overflowInlineSet) {
      map.put("overflow-inline", overflowInline.isPresent() ? overflowInline.get().toWireValue() : null);
    }
    if (pointerSet) {
      map.put("pointer", pointer.isPresent() ? pointer.get().toWireValue() : null);
    }
    if (prefersColorSchemeSet) {
      map.put("prefers-color-scheme", prefersColorScheme.isPresent() ? prefersColorScheme.get().toWireValue() : null);
    }
    if (prefersContrastSet) {
      map.put("prefers-contrast", prefersContrast.isPresent() ? prefersContrast.get().toWireValue() : null);
    }
    if (prefersReducedDataSet) {
      map.put("prefers-reduced-data", prefersReducedData.isPresent() ? prefersReducedData.get().toWireValue() : null);
    }
    if (prefersReducedMotionSet) {
      map.put("prefers-reduced-motion", prefersReducedMotion.isPresent() ? prefersReducedMotion.get().toWireValue() : null);
    }
    if (prefersReducedTransparencySet) {
      map.put("prefers-reduced-transparency", prefersReducedTransparency.isPresent() ? prefersReducedTransparency.get().toWireValue() : null);
    }
    if (scanSet) {
      map.put("scan", scan.isPresent() ? scan.get().toWireValue() : null);
    }
    if (scriptingSet) {
      map.put("scripting", scripting.isPresent() ? scripting.get().toWireValue() : null);
    }
    if (updateSet) {
      map.put("update", update.isPresent() ? update.get().toWireValue() : null);
    }
    if (verticalViewportSegmentsSet) {
      map.put("vertical-viewport-segments", verticalViewportSegments.isPresent() ? verticalViewportSegments.get() : null);
    }
    if (videoColorGamutSet) {
      map.put("video-color-gamut", videoColorGamut.isPresent() ? videoColorGamut.get().toWireValue() : null);
    }
    if (videoDynamicRangeSet) {
      map.put("video-dynamic-range", videoDynamicRange.isPresent() ? videoDynamicRange.get().toWireValue() : null);
    }
    return Collections.unmodifiableMap(map);
  }


  private static MediaFeatures fromJson(Map<String, Object> map) {
    Json json = ConverterFunctions.JSON;
    Optional<MediaFeatures.AnyHover> anyHover = json.toType(json.toJson(map.get("any-hover")), new TypeToken<Optional<MediaFeatures.AnyHover>>() {}.getType());
    Optional<MediaFeatures.AnyPointer> anyPointer = json.toType(json.toJson(map.get("any-pointer")), new TypeToken<Optional<MediaFeatures.AnyPointer>>() {}.getType());
    Optional<Long> color = json.toType(json.toJson(map.get("color")), new TypeToken<Optional<Long>>() {}.getType());
    Optional<MediaFeatures.ColorGamut> colorGamut = json.toType(json.toJson(map.get("color-gamut")), new TypeToken<Optional<MediaFeatures.ColorGamut>>() {}.getType());
    Optional<Long> colorIndex = json.toType(json.toJson(map.get("color-index")), new TypeToken<Optional<Long>>() {}.getType());
    Optional<MediaFeatures.DisplayMode> displayMode = json.toType(json.toJson(map.get("display-mode")), new TypeToken<Optional<MediaFeatures.DisplayMode>>() {}.getType());
    Optional<MediaFeatures.DynamicRange> dynamicRange = json.toType(json.toJson(map.get("dynamic-range")), new TypeToken<Optional<MediaFeatures.DynamicRange>>() {}.getType());
    Optional<MediaFeatures.EnvironmentBlending> environmentBlending = json.toType(json.toJson(map.get("environment-blending")), new TypeToken<Optional<MediaFeatures.EnvironmentBlending>>() {}.getType());
    Optional<MediaFeatures.ForcedColors> forcedColors = json.toType(json.toJson(map.get("forced-colors")), new TypeToken<Optional<MediaFeatures.ForcedColors>>() {}.getType());
    Optional<MediaFeatures.Grid> grid = json.toType(json.toJson(map.get("grid")), new TypeToken<Optional<MediaFeatures.Grid>>() {}.getType());
    Optional<Long> horizontalViewportSegments = json.toType(json.toJson(map.get("horizontal-viewport-segments")), new TypeToken<Optional<Long>>() {}.getType());
    Optional<MediaFeatures.Hover> hover = json.toType(json.toJson(map.get("hover")), new TypeToken<Optional<MediaFeatures.Hover>>() {}.getType());
    Optional<MediaFeatures.InvertedColors> invertedColors = json.toType(json.toJson(map.get("inverted-colors")), new TypeToken<Optional<MediaFeatures.InvertedColors>>() {}.getType());
    Optional<Long> monochrome = json.toType(json.toJson(map.get("monochrome")), new TypeToken<Optional<Long>>() {}.getType());
    Optional<MediaFeatures.NavControls> navControls = json.toType(json.toJson(map.get("nav-controls")), new TypeToken<Optional<MediaFeatures.NavControls>>() {}.getType());
    Optional<MediaFeatures.OverflowBlock> overflowBlock = json.toType(json.toJson(map.get("overflow-block")), new TypeToken<Optional<MediaFeatures.OverflowBlock>>() {}.getType());
    Optional<MediaFeatures.OverflowInline> overflowInline = json.toType(json.toJson(map.get("overflow-inline")), new TypeToken<Optional<MediaFeatures.OverflowInline>>() {}.getType());
    Optional<MediaFeatures.Pointer> pointer = json.toType(json.toJson(map.get("pointer")), new TypeToken<Optional<MediaFeatures.Pointer>>() {}.getType());
    Optional<MediaFeatures.PrefersColorScheme> prefersColorScheme = json.toType(json.toJson(map.get("prefers-color-scheme")), new TypeToken<Optional<MediaFeatures.PrefersColorScheme>>() {}.getType());
    Optional<MediaFeatures.PrefersContrast> prefersContrast = json.toType(json.toJson(map.get("prefers-contrast")), new TypeToken<Optional<MediaFeatures.PrefersContrast>>() {}.getType());
    Optional<MediaFeatures.PrefersReducedData> prefersReducedData = json.toType(json.toJson(map.get("prefers-reduced-data")), new TypeToken<Optional<MediaFeatures.PrefersReducedData>>() {}.getType());
    Optional<MediaFeatures.PrefersReducedMotion> prefersReducedMotion = json.toType(json.toJson(map.get("prefers-reduced-motion")), new TypeToken<Optional<MediaFeatures.PrefersReducedMotion>>() {}.getType());
    Optional<MediaFeatures.PrefersReducedTransparency> prefersReducedTransparency = json.toType(json.toJson(map.get("prefers-reduced-transparency")), new TypeToken<Optional<MediaFeatures.PrefersReducedTransparency>>() {}.getType());
    Optional<MediaFeatures.Scan> scan = json.toType(json.toJson(map.get("scan")), new TypeToken<Optional<MediaFeatures.Scan>>() {}.getType());
    Optional<MediaFeatures.Scripting> scripting = json.toType(json.toJson(map.get("scripting")), new TypeToken<Optional<MediaFeatures.Scripting>>() {}.getType());
    Optional<MediaFeatures.Update> update = json.toType(json.toJson(map.get("update")), new TypeToken<Optional<MediaFeatures.Update>>() {}.getType());
    Optional<Long> verticalViewportSegments = json.toType(json.toJson(map.get("vertical-viewport-segments")), new TypeToken<Optional<Long>>() {}.getType());
    Optional<MediaFeatures.VideoColorGamut> videoColorGamut = json.toType(json.toJson(map.get("video-color-gamut")), new TypeToken<Optional<MediaFeatures.VideoColorGamut>>() {}.getType());
    Optional<MediaFeatures.VideoDynamicRange> videoDynamicRange = json.toType(json.toJson(map.get("video-dynamic-range")), new TypeToken<Optional<MediaFeatures.VideoDynamicRange>>() {}.getType());
    return new MediaFeatures(anyHover, anyPointer, color, colorGamut, colorIndex, displayMode, dynamicRange, environmentBlending, forcedColors, grid, horizontalViewportSegments, hover, invertedColors, monochrome, navControls, overflowBlock, overflowInline, pointer, prefersColorScheme, prefersContrast, prefersReducedData, prefersReducedMotion, prefersReducedTransparency, scan, scripting, update, verticalViewportSegments, videoColorGamut, videoDynamicRange);
  }

  public enum AnyHover {

    NONE("none"),
    HOVER("hover");

    private final String value;

    AnyHover(String value) {
      this.value = value;
    }

    public static AnyHover fromJson(String s) {
      for (AnyHover e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown AnyHover value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum AnyPointer {

    NONE("none"),
    COARSE("coarse"),
    FINE("fine");

    private final String value;

    AnyPointer(String value) {
      this.value = value;
    }

    public static AnyPointer fromJson(String s) {
      for (AnyPointer e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown AnyPointer value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum ColorGamut {

    SRGB("srgb"),
    P3("p3"),
    REC2020("rec2020");

    private final String value;

    ColorGamut(String value) {
      this.value = value;
    }

    public static ColorGamut fromJson(String s) {
      for (ColorGamut e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown ColorGamut value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum DisplayMode {

    FULLSCREEN("fullscreen"),
    STANDALONE("standalone"),
    MINIMAL_UI("minimal-ui"),
    BROWSER("browser"),
    PICTURE_IN_PICTURE("picture-in-picture");

    private final String value;

    DisplayMode(String value) {
      this.value = value;
    }

    public static DisplayMode fromJson(String s) {
      for (DisplayMode e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown DisplayMode value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum DynamicRange {

    STANDARD("standard"),
    HIGH("high");

    private final String value;

    DynamicRange(String value) {
      this.value = value;
    }

    public static DynamicRange fromJson(String s) {
      for (DynamicRange e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown DynamicRange value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum EnvironmentBlending {

    OPAQUE("opaque"),
    ADDITIVE("additive"),
    SUBTRACTIVE("subtractive");

    private final String value;

    EnvironmentBlending(String value) {
      this.value = value;
    }

    public static EnvironmentBlending fromJson(String s) {
      for (EnvironmentBlending e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown EnvironmentBlending value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum ForcedColors {

    NONE("none"),
    ACTIVE("active");

    private final String value;

    ForcedColors(String value) {
      this.value = value;
    }

    public static ForcedColors fromJson(String s) {
      for (ForcedColors e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown ForcedColors value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum Grid {

    _0(0L),
    _1(1L);

    private final Long value;

    Grid(Long value) {
      this.value = value;
    }

    public static Grid fromJson(Long s) {
      for (Grid e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown Grid value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum Hover {

    NONE("none"),
    HOVER("hover");

    private final String value;

    Hover(String value) {
      this.value = value;
    }

    public static Hover fromJson(String s) {
      for (Hover e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown Hover value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum InvertedColors {

    NONE("none"),
    INVERTED("inverted");

    private final String value;

    InvertedColors(String value) {
      this.value = value;
    }

    public static InvertedColors fromJson(String s) {
      for (InvertedColors e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown InvertedColors value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum NavControls {

    NONE("none"),
    BACK("back");

    private final String value;

    NavControls(String value) {
      this.value = value;
    }

    public static NavControls fromJson(String s) {
      for (NavControls e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown NavControls value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum OverflowBlock {

    NONE("none"),
    SCROLL("scroll"),
    OPTIONAL_PAGED("optional-paged"),
    PAGED("paged");

    private final String value;

    OverflowBlock(String value) {
      this.value = value;
    }

    public static OverflowBlock fromJson(String s) {
      for (OverflowBlock e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown OverflowBlock value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum OverflowInline {

    NONE("none"),
    SCROLL("scroll");

    private final String value;

    OverflowInline(String value) {
      this.value = value;
    }

    public static OverflowInline fromJson(String s) {
      for (OverflowInline e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown OverflowInline value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum Pointer {

    NONE("none"),
    COARSE("coarse"),
    FINE("fine");

    private final String value;

    Pointer(String value) {
      this.value = value;
    }

    public static Pointer fromJson(String s) {
      for (Pointer e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown Pointer value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum PrefersColorScheme {

    LIGHT("light"),
    DARK("dark");

    private final String value;

    PrefersColorScheme(String value) {
      this.value = value;
    }

    public static PrefersColorScheme fromJson(String s) {
      for (PrefersColorScheme e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown PrefersColorScheme value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum PrefersContrast {

    NO_PREFERENCE("no-preference"),
    MORE("more"),
    LESS("less"),
    CUSTOM("custom");

    private final String value;

    PrefersContrast(String value) {
      this.value = value;
    }

    public static PrefersContrast fromJson(String s) {
      for (PrefersContrast e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown PrefersContrast value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum PrefersReducedData {

    NO_PREFERENCE("no-preference"),
    REDUCE("reduce");

    private final String value;

    PrefersReducedData(String value) {
      this.value = value;
    }

    public static PrefersReducedData fromJson(String s) {
      for (PrefersReducedData e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown PrefersReducedData value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum PrefersReducedMotion {

    NO_PREFERENCE("no-preference"),
    REDUCE("reduce");

    private final String value;

    PrefersReducedMotion(String value) {
      this.value = value;
    }

    public static PrefersReducedMotion fromJson(String s) {
      for (PrefersReducedMotion e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown PrefersReducedMotion value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum PrefersReducedTransparency {

    NO_PREFERENCE("no-preference"),
    REDUCE("reduce");

    private final String value;

    PrefersReducedTransparency(String value) {
      this.value = value;
    }

    public static PrefersReducedTransparency fromJson(String s) {
      for (PrefersReducedTransparency e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown PrefersReducedTransparency value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum Scan {

    INTERLACE("interlace"),
    PROGRESSIVE("progressive");

    private final String value;

    Scan(String value) {
      this.value = value;
    }

    public static Scan fromJson(String s) {
      for (Scan e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown Scan value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum Scripting {

    NONE("none"),
    INITIAL_ONLY("initial-only"),
    ENABLED("enabled");

    private final String value;

    Scripting(String value) {
      this.value = value;
    }

    public static Scripting fromJson(String s) {
      for (Scripting e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown Scripting value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum Update {

    NONE("none"),
    SLOW("slow"),
    FAST("fast");

    private final String value;

    Update(String value) {
      this.value = value;
    }

    public static Update fromJson(String s) {
      for (Update e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown Update value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum VideoColorGamut {

    SRGB("srgb"),
    P3("p3"),
    REC2020("rec2020");

    private final String value;

    VideoColorGamut(String value) {
      this.value = value;
    }

    public static VideoColorGamut fromJson(String s) {
      for (VideoColorGamut e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown VideoColorGamut value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }

  public enum VideoDynamicRange {

    STANDARD("standard"),
    HIGH("high");

    private final String value;

    VideoDynamicRange(String value) {
      this.value = value;
    }

    public static VideoDynamicRange fromJson(String s) {
      for (VideoDynamicRange e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown VideoDynamicRange value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }
}
