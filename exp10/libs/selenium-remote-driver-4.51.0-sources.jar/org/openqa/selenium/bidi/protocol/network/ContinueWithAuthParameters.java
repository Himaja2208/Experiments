// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.network;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public interface ContinueWithAuthParameters {

  Map<String, Object> toMap();

  @SuppressWarnings("unchecked")
  public static ContinueWithAuthParameters fromMap(Map<String, Object> map) {
    Object discriminator = map.get("action");
    if ("provideCredentials".equals(discriminator))
      return (ContinueWithAuthParameters)(Object) ConverterFunctions.fromMap(ContinueWithAuthParameters.Credentials.class).apply(map);
    return (ContinueWithAuthParameters)(Object) ConverterFunctions.fromMap(ContinueWithAuthParameters.NoCredentials.class).apply(map);
  }

  private static ContinueWithAuthParameters fromJson(Map<String, Object> map) {
    return fromMap(map);
  }

  public static class Credentials implements ContinueWithAuthParameters {

    private final String request;
    private final String action;
    private final AuthCredentials credentials;

    public Credentials(String request, String action, AuthCredentials credentials) {
      this.request = Objects.requireNonNull(request, "request is required");
      if (!Objects.equals(action, "provideCredentials")) {
        throw new BiDiException("action must be " + "provideCredentials" + ", got: " + action);
      }
      this.action = Objects.requireNonNull(action, "action is required");
      this.credentials = Objects.requireNonNull(credentials, "credentials is required");
    }

    public String getRequest() {
      return request;
    }

    public String getAction() {
      return action;
    }

    public AuthCredentials getCredentials() {
      return credentials;
    }

    @Override
    public Map<String, Object> toMap() {
      Map<String, Object> map = new LinkedHashMap<>();
      map.put("request", request);
      map.put("action", action);
      map.put("credentials", credentials.toMap());
      return Collections.unmodifiableMap(map);
    }

  }

  public static class NoCredentials implements ContinueWithAuthParameters {

    private final String request;
    private final ContinueWithAuthParameters.NoCredentials.Action action;

    public NoCredentials(String request, ContinueWithAuthParameters.NoCredentials.Action action) {
      this.request = Objects.requireNonNull(request, "request is required");
      this.action = Objects.requireNonNull(action, "action is required");
    }

    public String getRequest() {
      return request;
    }

    public ContinueWithAuthParameters.NoCredentials.Action getAction() {
      return action;
    }

    @Override
    public Map<String, Object> toMap() {
      Map<String, Object> map = new LinkedHashMap<>();
      map.put("request", request);
      map.put("action", action.toWireValue());
      return Collections.unmodifiableMap(map);
    }


    public enum Action {

      DEFAULT("default"),
      CANCEL("cancel");

      private final String value;

      Action(String value) {
        this.value = value;
      }

      public static Action fromJson(String s) {
        for (Action e : values()) {
          if (e.value.equals(s)) return e;
        }
        throw new BiDiException("Unknown Action value: " + s);
      }

      public Object toWireValue() {
        return value;
      }

      @Override
      public String toString() {
        return String.valueOf(value);
      }
    }
  }
}
