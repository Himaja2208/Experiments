// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.browsingcontext;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class MediaTrackConstraints {

  private Optional<Long> width;
  private Optional<Long> height;
  private Optional<Long> frameRate;

  public MediaTrackConstraints() {
    this.width = Optional.empty();
    this.height = Optional.empty();
    this.frameRate = Optional.empty();
  }

  MediaTrackConstraints(Optional<Long> width, Optional<Long> height, Optional<Long> frameRate) {
    if (width != null && width.isPresent() && (width.get() < 0L || width.get() > 9007199254740991L)) {
      throw new BiDiException("width must be between 0 and 9007199254740991, got: " + width.get());
    }
    this.width = width != null ? width : Optional.empty();
    if (height != null && height.isPresent() && (height.get() < 0L || height.get() > 9007199254740991L)) {
      throw new BiDiException("height must be between 0 and 9007199254740991, got: " + height.get());
    }
    this.height = height != null ? height : Optional.empty();
    if (frameRate != null && frameRate.isPresent() && (frameRate.get() < 0L || frameRate.get() > 9007199254740991L)) {
      throw new BiDiException("frameRate must be between 0 and 9007199254740991, got: " + frameRate.get());
    }
    this.frameRate = frameRate != null ? frameRate : Optional.empty();
  }

  public MediaTrackConstraints setWidth(Long width) {
    if (width != null && (width < 0L || width > 9007199254740991L)) {
      throw new BiDiException("width must be between 0 and 9007199254740991, got: " + width);
    }
    this.width = Optional.ofNullable(width);
    return this;
  }

  public MediaTrackConstraints setHeight(Long height) {
    if (height != null && (height < 0L || height > 9007199254740991L)) {
      throw new BiDiException("height must be between 0 and 9007199254740991, got: " + height);
    }
    this.height = Optional.ofNullable(height);
    return this;
  }

  public MediaTrackConstraints setFrameRate(Long frameRate) {
    if (frameRate != null && (frameRate < 0L || frameRate > 9007199254740991L)) {
      throw new BiDiException("frameRate must be between 0 and 9007199254740991, got: " + frameRate);
    }
    this.frameRate = Optional.ofNullable(frameRate);
    return this;
  }

  public Optional<Long> getWidth() {
    return width;
  }

  public Optional<Long> getHeight() {
    return height;
  }

  public Optional<Long> getFrameRate() {
    return frameRate;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    width.ifPresent(v -> map.put("width", v));
    height.ifPresent(v -> map.put("height", v));
    frameRate.ifPresent(v -> map.put("frameRate", v));
    return Collections.unmodifiableMap(map);
  }

}
