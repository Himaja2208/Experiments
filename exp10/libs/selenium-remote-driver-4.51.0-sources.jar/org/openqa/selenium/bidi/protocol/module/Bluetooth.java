// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.module;

import org.jetbrains.annotations.ApiStatus;
import org.openqa.selenium.Beta;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.bidi.Command;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.bidi.Event;
import org.openqa.selenium.bidi.Module;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
@SuppressWarnings("unchecked")
public class Bluetooth extends Module {

  public static final Event<org.openqa.selenium.bidi.protocol.bluetooth.RequestDevicePromptUpdatedParameters> REQUEST_DEVICE_PROMPT_UPDATED =
      new Event<>("bluetooth.requestDevicePromptUpdated", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.bluetooth.RequestDevicePromptUpdatedParameters.class));

  public static final Event<org.openqa.selenium.bidi.protocol.bluetooth.GattConnectionAttemptedParameters> GATT_CONNECTION_ATTEMPTED =
      new Event<>("bluetooth.gattConnectionAttempted", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.bluetooth.GattConnectionAttemptedParameters.class));

  public static final Event<org.openqa.selenium.bidi.protocol.bluetooth.CharacteristicEventGeneratedParameters> CHARACTERISTIC_EVENT_GENERATED =
      new Event<>("bluetooth.characteristicEventGenerated", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.bluetooth.CharacteristicEventGeneratedParameters.class));

  public static final Event<org.openqa.selenium.bidi.protocol.bluetooth.DescriptorEventGeneratedParameters> DESCRIPTOR_EVENT_GENERATED =
      new Event<>("bluetooth.descriptorEventGenerated", ConverterFunctions.fromMap(org.openqa.selenium.bidi.protocol.bluetooth.DescriptorEventGeneratedParameters.class));

  public Bluetooth(WebDriver driver) {
    super(driver);
  }

  public void handleRequestDevicePrompt(org.openqa.selenium.bidi.protocol.bluetooth.HandleRequestDevicePromptParameters params) {
    send(new Command<>("bluetooth.handleRequestDevicePrompt", params.toMap()));
  }

  public void simulateAdapter(org.openqa.selenium.bidi.protocol.bluetooth.SimulateAdapterParameters params) {
    send(new Command<>("bluetooth.simulateAdapter", params.toMap()));
  }

  public void disableSimulation(org.openqa.selenium.bidi.protocol.bluetooth.DisableSimulationParameters params) {
    send(new Command<>("bluetooth.disableSimulation", params.toMap()));
  }

  public void simulatePreconnectedPeripheral(org.openqa.selenium.bidi.protocol.bluetooth.SimulatePreconnectedPeripheralParameters params) {
    send(new Command<>("bluetooth.simulatePreconnectedPeripheral", params.toMap()));
  }

  public void simulateAdvertisement(org.openqa.selenium.bidi.protocol.bluetooth.SimulateAdvertisementParameters params) {
    send(new Command<>("bluetooth.simulateAdvertisement", params.toMap()));
  }

  public void simulateGattConnectionResponse(org.openqa.selenium.bidi.protocol.bluetooth.SimulateGattConnectionResponseParameters params) {
    send(new Command<>("bluetooth.simulateGattConnectionResponse", params.toMap()));
  }

  public void simulateGattDisconnection(org.openqa.selenium.bidi.protocol.bluetooth.SimulateGattDisconnectionParameters params) {
    send(new Command<>("bluetooth.simulateGattDisconnection", params.toMap()));
  }

  public void simulateService(org.openqa.selenium.bidi.protocol.bluetooth.SimulateServiceParameters params) {
    send(new Command<>("bluetooth.simulateService", params.toMap()));
  }

  public void simulateCharacteristic(org.openqa.selenium.bidi.protocol.bluetooth.SimulateCharacteristicParameters params) {
    send(new Command<>("bluetooth.simulateCharacteristic", params.toMap()));
  }

  public void simulateCharacteristicResponse(org.openqa.selenium.bidi.protocol.bluetooth.SimulateCharacteristicResponseParameters params) {
    send(new Command<>("bluetooth.simulateCharacteristicResponse", params.toMap()));
  }

  public void simulateDescriptor(org.openqa.selenium.bidi.protocol.bluetooth.SimulateDescriptorParameters params) {
    send(new Command<>("bluetooth.simulateDescriptor", params.toMap()));
  }

  public void simulateDescriptorResponse(org.openqa.selenium.bidi.protocol.bluetooth.SimulateDescriptorResponseParameters params) {
    send(new Command<>("bluetooth.simulateDescriptorResponse", params.toMap()));
  }

}
