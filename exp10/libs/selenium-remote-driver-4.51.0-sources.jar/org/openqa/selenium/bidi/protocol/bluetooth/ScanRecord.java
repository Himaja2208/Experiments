// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.bluetooth;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class ScanRecord {

  private Optional<String> name;
  private Optional<java.util.List<String>> uuids;
  private Optional<Number> appearance;
  private Optional<java.util.List<BluetoothManufacturerData>> manufacturerData;

  public ScanRecord() {
    this.name = Optional.empty();
    this.uuids = Optional.empty();
    this.appearance = Optional.empty();
    this.manufacturerData = Optional.empty();
  }

  ScanRecord(Optional<String> name, Optional<java.util.List<String>> uuids, Optional<Number> appearance, Optional<java.util.List<BluetoothManufacturerData>> manufacturerData) {
    this.name = name != null ? name : Optional.empty();
    this.uuids = uuids != null ? uuids : Optional.empty();
    this.appearance = appearance != null ? appearance : Optional.empty();
    this.manufacturerData = manufacturerData != null ? manufacturerData : Optional.empty();
  }

  public ScanRecord setName(String name) {
    this.name = Optional.ofNullable(name);
    return this;
  }

  public ScanRecord setUuids(java.util.List<String> uuids) {
    this.uuids = Optional.ofNullable(uuids);
    return this;
  }

  public ScanRecord setAppearance(Number appearance) {
    this.appearance = Optional.ofNullable(appearance);
    return this;
  }

  public ScanRecord setManufacturerData(java.util.List<BluetoothManufacturerData> manufacturerData) {
    this.manufacturerData = Optional.ofNullable(manufacturerData);
    return this;
  }

  public Optional<String> getName() {
    return name;
  }

  public Optional<java.util.List<String>> getUuids() {
    return uuids;
  }

  public Optional<Number> getAppearance() {
    return appearance;
  }

  public Optional<java.util.List<BluetoothManufacturerData>> getManufacturerData() {
    return manufacturerData;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    name.ifPresent(v -> map.put("name", v));
    uuids.ifPresent(v -> map.put("uuids", v.stream().map(e -> java.util.Objects.requireNonNull(e, "uuids element must not be null")).collect(java.util.stream.Collectors.toList())));
    appearance.ifPresent(v -> map.put("appearance", v));
    manufacturerData.ifPresent(v -> map.put("manufacturerData", v.stream().map(e -> java.util.Objects.requireNonNull(e, "manufacturerData element must not be null").toMap()).collect(java.util.stream.Collectors.toList())));
    return Collections.unmodifiableMap(map);
  }

}
