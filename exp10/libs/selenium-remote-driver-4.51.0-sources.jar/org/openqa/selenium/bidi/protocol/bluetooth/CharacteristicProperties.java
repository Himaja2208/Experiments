// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.bluetooth;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class CharacteristicProperties {

  private Optional<Boolean> broadcast;
  private Optional<Boolean> read;
  private Optional<Boolean> writeWithoutResponse;
  private Optional<Boolean> write;
  private Optional<Boolean> notify;
  private Optional<Boolean> indicate;
  private Optional<Boolean> authenticatedSignedWrites;
  private Optional<Boolean> extendedProperties;

  public CharacteristicProperties() {
    this.broadcast = Optional.empty();
    this.read = Optional.empty();
    this.writeWithoutResponse = Optional.empty();
    this.write = Optional.empty();
    this.notify = Optional.empty();
    this.indicate = Optional.empty();
    this.authenticatedSignedWrites = Optional.empty();
    this.extendedProperties = Optional.empty();
  }

  CharacteristicProperties(Optional<Boolean> broadcast, Optional<Boolean> read, Optional<Boolean> writeWithoutResponse, Optional<Boolean> write, Optional<Boolean> notify, Optional<Boolean> indicate, Optional<Boolean> authenticatedSignedWrites, Optional<Boolean> extendedProperties) {
    this.broadcast = broadcast != null ? broadcast : Optional.empty();
    this.read = read != null ? read : Optional.empty();
    this.writeWithoutResponse = writeWithoutResponse != null ? writeWithoutResponse : Optional.empty();
    this.write = write != null ? write : Optional.empty();
    this.notify = notify != null ? notify : Optional.empty();
    this.indicate = indicate != null ? indicate : Optional.empty();
    this.authenticatedSignedWrites = authenticatedSignedWrites != null ? authenticatedSignedWrites : Optional.empty();
    this.extendedProperties = extendedProperties != null ? extendedProperties : Optional.empty();
  }

  public CharacteristicProperties setBroadcast(Boolean broadcast) {
    this.broadcast = Optional.ofNullable(broadcast);
    return this;
  }

  public CharacteristicProperties setRead(Boolean read) {
    this.read = Optional.ofNullable(read);
    return this;
  }

  public CharacteristicProperties setWriteWithoutResponse(Boolean writeWithoutResponse) {
    this.writeWithoutResponse = Optional.ofNullable(writeWithoutResponse);
    return this;
  }

  public CharacteristicProperties setWrite(Boolean write) {
    this.write = Optional.ofNullable(write);
    return this;
  }

  public CharacteristicProperties setNotify(Boolean notify) {
    this.notify = Optional.ofNullable(notify);
    return this;
  }

  public CharacteristicProperties setIndicate(Boolean indicate) {
    this.indicate = Optional.ofNullable(indicate);
    return this;
  }

  public CharacteristicProperties setAuthenticatedSignedWrites(Boolean authenticatedSignedWrites) {
    this.authenticatedSignedWrites = Optional.ofNullable(authenticatedSignedWrites);
    return this;
  }

  public CharacteristicProperties setExtendedProperties(Boolean extendedProperties) {
    this.extendedProperties = Optional.ofNullable(extendedProperties);
    return this;
  }

  public Optional<Boolean> getBroadcast() {
    return broadcast;
  }

  public Optional<Boolean> getRead() {
    return read;
  }

  public Optional<Boolean> getWriteWithoutResponse() {
    return writeWithoutResponse;
  }

  public Optional<Boolean> getWrite() {
    return write;
  }

  public Optional<Boolean> getNotify() {
    return notify;
  }

  public Optional<Boolean> getIndicate() {
    return indicate;
  }

  public Optional<Boolean> getAuthenticatedSignedWrites() {
    return authenticatedSignedWrites;
  }

  public Optional<Boolean> getExtendedProperties() {
    return extendedProperties;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    broadcast.ifPresent(v -> map.put("broadcast", v));
    read.ifPresent(v -> map.put("read", v));
    writeWithoutResponse.ifPresent(v -> map.put("writeWithoutResponse", v));
    write.ifPresent(v -> map.put("write", v));
    notify.ifPresent(v -> map.put("notify", v));
    indicate.ifPresent(v -> map.put("indicate", v));
    authenticatedSignedWrites.ifPresent(v -> map.put("authenticatedSignedWrites", v));
    extendedProperties.ifPresent(v -> map.put("extendedProperties", v));
    return Collections.unmodifiableMap(map);
  }

}
