// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.browsingcontext;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public interface DownloadEndParams {

  @SuppressWarnings("unchecked")
  public static DownloadEndParams fromMap(Map<String, Object> map) {
    Object discriminator = map.get("status");
    if ("canceled".equals(discriminator))
      return (DownloadEndParams)(Object) ConverterFunctions.fromMap(DownloadEndParams.CanceledParams.class).apply(map);
    if ("complete".equals(discriminator))
      return (DownloadEndParams)(Object) ConverterFunctions.fromMap(DownloadEndParams.CompleteParams.class).apply(map);
    throw new BiDiException("Unknown DownloadEndParams discriminator '" + discriminator + "'");
  }

  private static DownloadEndParams fromJson(Map<String, Object> map) {
    return fromMap(map);
  }

  @WarnOnUnknownFields
  public static class CanceledParams implements DownloadEndParams {

    private final String status;
    private final String download;
    private final String context;
    private final String navigation;
    private final long timestamp;
    private final String url;
    private final Optional<String> userContext;

    CanceledParams(String status, String download, String context, @Nullable String navigation, long timestamp, String url, Optional<String> userContext) {
      if (!Objects.equals(status, "canceled")) {
        throw new BiDiException("status must be " + "canceled" + ", got: " + status);
      }
      this.status = Objects.requireNonNull(status, "status is required");
      this.download = Objects.requireNonNull(download, "download is required");
      this.context = Objects.requireNonNull(context, "context is required");
      this.navigation = navigation;
      if (timestamp < 0L || timestamp > 9007199254740991L) {
        throw new BiDiException("timestamp must be between 0 and 9007199254740991, got: " + timestamp);
      }
      this.timestamp = timestamp;
      this.url = Objects.requireNonNull(url, "url is required");
      this.userContext = userContext != null ? userContext : Optional.empty();
    }

    public String getStatus() {
      return status;
    }

    public String getDownload() {
      return download;
    }

    public String getContext() {
      return context;
    }

    public String getNavigation() {
      return navigation;
    }

    public long getTimestamp() {
      return timestamp;
    }

    public String getUrl() {
      return url;
    }

    public Optional<String> getUserContext() {
      return userContext;
    }

  }

  @WarnOnUnknownFields
  public static class CompleteParams implements DownloadEndParams {

    private final String status;
    private final String download;
    private final String filepath;
    private final String context;
    private final String navigation;
    private final long timestamp;
    private final String url;
    private final Optional<String> userContext;

    CompleteParams(String status, String download, @Nullable String filepath, String context, @Nullable String navigation, long timestamp, String url, Optional<String> userContext) {
      if (!Objects.equals(status, "complete")) {
        throw new BiDiException("status must be " + "complete" + ", got: " + status);
      }
      this.status = Objects.requireNonNull(status, "status is required");
      this.download = Objects.requireNonNull(download, "download is required");
      this.filepath = filepath;
      this.context = Objects.requireNonNull(context, "context is required");
      this.navigation = navigation;
      if (timestamp < 0L || timestamp > 9007199254740991L) {
        throw new BiDiException("timestamp must be between 0 and 9007199254740991, got: " + timestamp);
      }
      this.timestamp = timestamp;
      this.url = Objects.requireNonNull(url, "url is required");
      this.userContext = userContext != null ? userContext : Optional.empty();
    }

    public String getStatus() {
      return status;
    }

    public String getDownload() {
      return download;
    }

    public String getFilepath() {
      return filepath;
    }

    public String getContext() {
      return context;
    }

    public String getNavigation() {
      return navigation;
    }

    public long getTimestamp() {
      return timestamp;
    }

    public String getUrl() {
      return url;
    }

    public Optional<String> getUserContext() {
      return userContext;
    }

  }
}
