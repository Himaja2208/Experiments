// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.browsingcontext;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class StartScreencastParameters {

  private final String context;
  private Optional<String> destinationFolder;
  private Optional<String> mimeType;
  private Optional<MediaTrackConstraints> video;
  private Optional<Boolean> audio;

  public StartScreencastParameters(String context) {
    this.context = Objects.requireNonNull(context, "context is required");
    this.destinationFolder = Optional.empty();
    this.mimeType = Optional.empty();
    this.video = Optional.empty();
    this.audio = Optional.empty();
  }

  StartScreencastParameters(String context, Optional<String> destinationFolder, Optional<String> mimeType, Optional<MediaTrackConstraints> video, Optional<Boolean> audio) {
    this.context = Objects.requireNonNull(context, "context is required");
    this.destinationFolder = destinationFolder != null ? destinationFolder : Optional.empty();
    this.mimeType = mimeType != null ? mimeType : Optional.empty();
    this.video = video != null ? video : Optional.empty();
    this.audio = audio != null ? audio : Optional.empty();
  }

  public StartScreencastParameters setDestinationFolder(String destinationFolder) {
    this.destinationFolder = Optional.ofNullable(destinationFolder);
    return this;
  }

  public StartScreencastParameters setMimeType(String mimeType) {
    this.mimeType = Optional.ofNullable(mimeType);
    return this;
  }

  public StartScreencastParameters setVideo(MediaTrackConstraints video) {
    this.video = Optional.ofNullable(video);
    return this;
  }

  public StartScreencastParameters setAudio(Boolean audio) {
    this.audio = Optional.ofNullable(audio);
    return this;
  }

  public String getContext() {
    return context;
  }

  public Optional<String> getDestinationFolder() {
    return destinationFolder;
  }

  public Optional<String> getMimeType() {
    return mimeType;
  }

  public Optional<MediaTrackConstraints> getVideo() {
    return video;
  }

  public Optional<Boolean> getAudio() {
    return audio;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("context", context);
    destinationFolder.ifPresent(v -> map.put("destinationFolder", v));
    mimeType.ifPresent(v -> map.put("mimeType", v));
    video.ifPresent(v -> map.put("video", v.toMap()));
    audio.ifPresent(v -> map.put("audio", v));
    return Collections.unmodifiableMap(map);
  }

}
