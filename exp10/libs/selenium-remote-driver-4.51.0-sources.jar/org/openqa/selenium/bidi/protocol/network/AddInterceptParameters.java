// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.network;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class AddInterceptParameters {

  private final java.util.List<InterceptPhase> phases;
  private Optional<java.util.List<String>> contexts;
  private Optional<java.util.List<UrlPattern>> urlPatterns;

  public AddInterceptParameters(java.util.List<InterceptPhase> phases) {
    this.phases = Objects.requireNonNull(phases, "phases is required");
    this.contexts = Optional.empty();
    this.urlPatterns = Optional.empty();
  }

  AddInterceptParameters(java.util.List<InterceptPhase> phases, Optional<java.util.List<String>> contexts, Optional<java.util.List<UrlPattern>> urlPatterns) {
    this.phases = Objects.requireNonNull(phases, "phases is required");
    this.contexts = contexts != null ? contexts : Optional.empty();
    this.urlPatterns = urlPatterns != null ? urlPatterns : Optional.empty();
  }

  public AddInterceptParameters setContexts(java.util.List<String> contexts) {
    this.contexts = Optional.ofNullable(contexts);
    return this;
  }

  public AddInterceptParameters setUrlPatterns(java.util.List<UrlPattern> urlPatterns) {
    this.urlPatterns = Optional.ofNullable(urlPatterns);
    return this;
  }

  public java.util.List<InterceptPhase> getPhases() {
    return phases;
  }

  public Optional<java.util.List<String>> getContexts() {
    return contexts;
  }

  public Optional<java.util.List<UrlPattern>> getUrlPatterns() {
    return urlPatterns;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("phases", phases.stream().map(e -> java.util.Objects.requireNonNull(e, "phases element must not be null").toWireValue()).collect(java.util.stream.Collectors.toList()));
    contexts.ifPresent(v -> map.put("contexts", v.stream().map(e -> java.util.Objects.requireNonNull(e, "contexts element must not be null")).collect(java.util.stream.Collectors.toList())));
    urlPatterns.ifPresent(v -> map.put("urlPatterns", v.stream().map(e -> java.util.Objects.requireNonNull(e, "urlPatterns element must not be null").toMap()).collect(java.util.stream.Collectors.toList())));
    return Collections.unmodifiableMap(map);
  }

}
