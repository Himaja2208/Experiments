// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.input;

import java.util.Map;
import org.jetbrains.annotations.ApiStatus;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public interface Origin {

  Object toWireValue();

  @SuppressWarnings("unchecked")
  static Origin fromJson(Object raw) {
    if (raw instanceof String) {
      return Literal.fromJson((String) raw);
    }
    if (raw instanceof Map) {
      return (Origin) (Object) ConverterFunctions.fromMap(ElementOrigin.class).apply((Map<String, Object>) raw);
    }
    throw new BiDiException("Expected a string or an object for Origin, got: " + raw);
  }

  enum Literal implements Origin {

    VIEWPORT("viewport"),
    POINTER("pointer");

    private final String value;

    Literal(String value) {
      this.value = value;
    }

    public static Literal fromJson(String s) {
      for (Literal e : values()) {
        if (e.value.equals(s)) return e;
      }
      throw new BiDiException("Unknown Literal value: " + s);
    }

    public Object toWireValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
  }
}
