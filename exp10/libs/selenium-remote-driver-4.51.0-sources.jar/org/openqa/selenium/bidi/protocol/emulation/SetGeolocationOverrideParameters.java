// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.emulation;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public interface SetGeolocationOverrideParameters {

  Map<String, Object> toMap();

  @SuppressWarnings("unchecked")
  public static SetGeolocationOverrideParameters fromMap(Map<String, Object> map) {
    if (map.containsKey("coordinates"))
      return (SetGeolocationOverrideParameters)(Object) ConverterFunctions.fromMap(SetGeolocationOverrideParameters.Coordinates.class).apply(map);
    if (map.containsKey("error"))
      return (SetGeolocationOverrideParameters)(Object) ConverterFunctions.fromMap(SetGeolocationOverrideParameters.Error.class).apply(map);
    throw new BiDiException("Cannot determine SetGeolocationOverrideParameters variant from fields: " + map.keySet());
  }

  private static SetGeolocationOverrideParameters fromJson(Map<String, Object> map) {
    return fromMap(map);
  }

  public static class Coordinates implements SetGeolocationOverrideParameters {

    private Optional<java.util.List<String>> contexts;
    private Optional<java.util.List<String>> userContexts;
    private final GeolocationCoordinates coordinates;

    public Coordinates(@Nullable GeolocationCoordinates coordinates) {
      this.coordinates = coordinates;
      this.contexts = Optional.empty();
      this.userContexts = Optional.empty();
    }

    Coordinates(Optional<java.util.List<String>> contexts, Optional<java.util.List<String>> userContexts, @Nullable GeolocationCoordinates coordinates) {
      this.contexts = contexts != null ? contexts : Optional.empty();
      this.userContexts = userContexts != null ? userContexts : Optional.empty();
      this.coordinates = coordinates;
    }

    public Coordinates setContexts(java.util.List<String> contexts) {
      this.contexts = Optional.ofNullable(contexts);
      return this;
    }

    public Coordinates setUserContexts(java.util.List<String> userContexts) {
      this.userContexts = Optional.ofNullable(userContexts);
      return this;
    }

    public Optional<java.util.List<String>> getContexts() {
      return contexts;
    }

    public Optional<java.util.List<String>> getUserContexts() {
      return userContexts;
    }

    public GeolocationCoordinates getCoordinates() {
      return coordinates;
    }

    @Override
    public Map<String, Object> toMap() {
      Map<String, Object> map = new LinkedHashMap<>();
      map.put("coordinates", coordinates == null ? null : coordinates.toMap());
      contexts.ifPresent(v -> map.put("contexts", v.stream().map(e -> java.util.Objects.requireNonNull(e, "contexts element must not be null")).collect(java.util.stream.Collectors.toList())));
      userContexts.ifPresent(v -> map.put("userContexts", v.stream().map(e -> java.util.Objects.requireNonNull(e, "userContexts element must not be null")).collect(java.util.stream.Collectors.toList())));
      return Collections.unmodifiableMap(map);
    }

  }

  public static class Error implements SetGeolocationOverrideParameters {

    private Optional<java.util.List<String>> contexts;
    private Optional<java.util.List<String>> userContexts;
    private final GeolocationPositionError error;

    public Error(GeolocationPositionError error) {
      this.error = Objects.requireNonNull(error, "error is required");
      this.contexts = Optional.empty();
      this.userContexts = Optional.empty();
    }

    Error(Optional<java.util.List<String>> contexts, Optional<java.util.List<String>> userContexts, GeolocationPositionError error) {
      this.contexts = contexts != null ? contexts : Optional.empty();
      this.userContexts = userContexts != null ? userContexts : Optional.empty();
      this.error = Objects.requireNonNull(error, "error is required");
    }

    public Error setContexts(java.util.List<String> contexts) {
      this.contexts = Optional.ofNullable(contexts);
      return this;
    }

    public Error setUserContexts(java.util.List<String> userContexts) {
      this.userContexts = Optional.ofNullable(userContexts);
      return this;
    }

    public Optional<java.util.List<String>> getContexts() {
      return contexts;
    }

    public Optional<java.util.List<String>> getUserContexts() {
      return userContexts;
    }

    public GeolocationPositionError getError() {
      return error;
    }

    @Override
    public Map<String, Object> toMap() {
      Map<String, Object> map = new LinkedHashMap<>();
      map.put("error", error.toMap());
      contexts.ifPresent(v -> map.put("contexts", v.stream().map(e -> java.util.Objects.requireNonNull(e, "contexts element must not be null")).collect(java.util.stream.Collectors.toList())));
      userContexts.ifPresent(v -> map.put("userContexts", v.stream().map(e -> java.util.Objects.requireNonNull(e, "userContexts element must not be null")).collect(java.util.stream.Collectors.toList())));
      return Collections.unmodifiableMap(map);
    }

  }
}
