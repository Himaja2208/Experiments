// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

package org.openqa.selenium.bidi.emulation;

import java.util.List;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;

@Beta
public class SetScriptingEnabledParameters extends AbstractOverrideParameters {
  public static SetScriptingEnabledParameters scriptingEnabled() {
    return new SetScriptingEnabledParameters(null);
  }

  public static SetScriptingEnabledParameters scriptingDisabled() {
    return new SetScriptingEnabledParameters(false);
  }

  public SetScriptingEnabledParameters(@Nullable Boolean enabled) {
    if (Boolean.TRUE.equals(enabled)) {
      throw new IllegalArgumentException(
          "Only emulation of disabled JavaScript is supported (enabled must be false or null)");
    }
    map.put("enabled", enabled); // null or false
  }

  @Override
  public SetScriptingEnabledParameters contexts(List<String> contexts) {
    super.contexts(contexts);
    return this;
  }

  @Override
  public SetScriptingEnabledParameters userContexts(List<String> userContexts) {
    super.userContexts(userContexts);
    return this;
  }
}
